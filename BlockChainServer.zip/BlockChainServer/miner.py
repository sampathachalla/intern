import zmq
import json
import concurrent.futures
import time
from datetime import datetime
from multiprocessing import Process, Manager
import multiprocessing
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
import blake3
import base58

ID = "miner-1"

# Node Database code starts here
# Dictionary for mapping pub_addr with wallet_id and ip_addr
pubToId = {}
wallets = {}
blocks={}
block_hash=""
block_counter=0
# Dictionary list of only full node
fullNodeIps = {}

def fullNodeConstructor():
    fullNodeIps["node-1"] = "tcp://localhost:5001"
    fullNodeIps["node-2"] = "tcp://localhost:5002"

def allNodeConstructor():
    pass

# Node Database code ends here

# Function for registering the wallets in the node
def wallet_register(arg,rid,mempool):
    status_code=200
    message="Wallet Registration Completed"
    wallet_ID=arg["walletID"]
    pub_addr=arg["pubAddr"]
    ip_addr=arg["ipAddr"]
    policy_list=arg["policyList"]
    request_list=arg["requestList"]
    """if pub_addr==public_key_to_address(deserialize_public_key(pub_key)):
        print("No changes in public key")
    else:
        print("Changes in the public key")
        status_code=500
        message="Wallet Registration Failed due to key change"""

    if wallet_ID in wallets:
        old_pub=wallets[wallet_ID]["pubAddr"]
        del pubToId[old_pub]
        del wallets[wallet_ID]
        wallets[wallet_ID]={"pubAddr":pub_addr,"ipAddr":ip_addr,"policyList":policy_list,"requestList":request_list}
        pubToId[pub_addr]=wallet_ID

    else:
        wallets[wallet_ID]={"pubAddr":pub_addr,"ipAddr":ip_addr,"policyList":policy_list,"requestList":request_list}
        pubToId[pub_addr]=wallet_ID

    return {"response_id":ID,"statusCode":status_code,"message":message}

#Function for registering the policy request transaction and storing in the memorypool
def policy_register(arg,rid,mempool):
    message="Policy Request Transaction Submitted"
    status_code=200
    #Extracting arguments
    transaction_id=arg["TXID"]
    if status_code==200:
        #Adding transactions to the mempool
        mempool[transaction_id]=arg
    
    if status_code==200:
        #Adding transactions to the mempool
        mempool[transaction_id]=arg
        mempool[transaction_id]["rid"]=rid
        print(f"trandsaction of Id {transaction_id} is registered in memory pool of {ID}")
    return {"response_id":ID,"statusCode":status_code,"message":message}

#Function for registering the policy request transaction and storing in the memorypool
def service_register(arg,rid,mempool):
    message="Service Request Transaction Submitted"
    status_code=200
    #Extracting arguments
    transaction_id=arg["TXID"]
    if status_code==200:
        #Adding transactions to the mempool
        mempool[transaction_id]=arg
    
    if status_code==200:
        #Adding transactions to the mempool
        mempool[transaction_id]=arg
        mempool[transaction_id]["rid"]=rid
        print(f"trandsaction of Id {transaction_id} is registered in memory pool of {ID}")
    return {"response_id":ID,"statusCode":status_code,"message":message}
    

def genesis_block(mempool, shared_data):
    print("block0 is constructed")
    # Constructing the block header
    version = 1
    merkle_root = f"mrkrtb0"
    now = datetime.now()
    timestamp = now.strftime("%Y%m%d%H%M%S")[:-3]
    nonce = 1000
    difficulty_target = 30
    transactions_count = len(mempool)
    block_header = {"previousBlockHash": "", "version": version, "mrkleRoot": merkle_root, "timestamp": timestamp, "none": nonce, "difficulty": difficulty_target, "count": transactions_count}
    block_body = dict(mempool)  # Make a copy of the mempool for the block body
    block = {"head": block_header, "body": block_body}
    shared_data["block_counter"] += 1
    shared_data["block_hash"] = "block0"
    print(block)
    return block

def construct_block(mempool, shared_data):
    if shared_data["block_counter"] == 0:
        return genesis_block(mempool, shared_data)
    previous_block_hash = shared_data["block_hash"]
    block_hash = f"block{shared_data['block_counter']}"
    print(f"{block_hash} is constructed")
    version = 1
    merkle_root = f"mrkrtb{shared_data['block_counter']}"
    now = datetime.now()
    timestamp = now.strftime("%Y%m%d%H%M%S%f")[:-3]
    nonce = 1000
    difficulty_target = 30
    transactions_count = len(mempool)
    block_header = {"previousBlockHash": previous_block_hash, "version": version, "mrkleRoot": merkle_root, "timestamp": timestamp, "none": nonce, "difficulty": difficulty_target, "count": transactions_count}
    block_body = dict(mempool)  # Make a copy of the mempool for the block body
    block = {"head": block_header, "body": block_body}
    shared_data["block_counter"] += 1
    shared_data["block_hash"] = block_hash
    print(block)
    return block

def broadcast_block(mempool, shared_data):
    status_code = 200
    arg = construct_block(mempool, shared_data)
    # Broadcasting further for all the nodes
    nodesList = list(fullNodeIps.values())
    request = {"request_id": ID, "fun_code": "vBlock", "arguments": arg}
    #print("Broadcasting the block to neighbouring nodes")
    red_flag = server_client(request, nodesList)
    if red_flag:
        status_code = 500
        message = "Block Broadcasting failed due to internal server issues"
    if status_code == 200:
        pass
        #print(f"Block is verified")

    # Adding the block to all the nodes
    mempool.clear()
    request = {"request_id": ID, "fun_code": "addBlock", "arguments": arg}
    #print("Adding the block")
    red_flag = server_client(request, nodesList)
    if red_flag:
        status_code = 500
        message = "Block addition failed due to internal server issues"
    if status_code == 200:
        print(shared_data["block_hash"]+" is added")
        shared_data["blocks[block_hash]"]=arg

def verify_block():
    pass

def run_periodically(mempool, shared_data):
    while True:
        client_process = multiprocessing.Process(target=broadcast_block, args=(mempool, shared_data,))
        client_process.start()
        client_process.join()
        time.sleep(5)

# Client Code Starts Here
def send_request(server_address, request_message):
    context = zmq.Context()
    socket = context.socket(zmq.REQ)
    socket.connect(server_address)
    socket.send(request_message)
    reply_message = socket.recv()
    reply = json.loads(reply_message.decode('utf-8'))
    socket.close()
    context.term()
    return reply

def server_client(request, server_addresses):
    red_flag = False
    if not server_addresses:
        print("No neighbouring nodes")
        return

    request_message = json.dumps(request).encode('utf-8')

    with concurrent.futures.ProcessPoolExecutor(max_workers=len(server_addresses)) as executor:
        futures = [executor.submit(send_request, server_address, request_message) for server_address in server_addresses]

        for future in concurrent.futures.as_completed(futures):
            try:
                result = future.result()
                if result['statusCode'] == 500:
                    print(f"{result['response_id']}:{result['statusCode']},{result['message']}")
                    red_flag = True
            except Exception as exc:
                print(f"Request generated an exception: {exc}")
    return red_flag

# Client Code Ends Here

# Server Code Starts Here
def worker(worker_url, worker_id, mempool):
    import json
    context = zmq.Context()
    socket = context.socket(zmq.DEALER)
    socket.identity = worker_id.encode('utf-8')
    socket.connect(worker_url)

    while True:
        try:
            reply = {}
            message = socket.recv_multipart()
            client_address, empty, request = message
            data = json.loads(request.decode('utf-8'))
            fun = data["fun_code"]
            if fun == "register":
                reply = wallet_register(data["arguments"], data["request_id"], mempool)
            elif fun == "vPolicyReq":
                reply = policy_register(data["arguments"], data["request_id"], mempool)
            elif fun == "vServiceReq":
                reply = service_register(data["arguments"], data["request_id"], mempool)
            reply_message = json.dumps(reply).encode('utf-8')
            socket.send_multipart([client_address, b'', reply_message])
        except Exception as e:
            print(f"Worker {worker_id} encountered an error: {e}")

def start_worker(worker_id, mempool):
    worker("ipc://backend.ipc", worker_id, mempool)

def server(mempool):
    print("Miner-1 started")
    context = zmq.Context()
    frontend = context.socket(zmq.ROUTER)
    frontend.bind("tcp://*:6001")
    backend = context.socket(zmq.DEALER)
    backend.bind("ipc://backend.ipc")

    for i in range(1):
        Process(target=start_worker, args=(f"worker-{i}", mempool)).start()

    try:
        zmq.proxy(frontend, backend)
    except KeyboardInterrupt:
        print("Server interrupted and shutting down.")
    finally:
        frontend.close()
        backend.close()
        context.term()

# Server Code Ends Here
fullNodeConstructor()

if __name__ == "__main__":
    manager = Manager()
    mempool = manager.dict()  # Create a shared dictionary for the mempool
    shared_data = manager.dict()  # Create a shared dictionary for shared data like block_hash and block_counter
    shared_data["block_counter"] = 0
    shared_data["block_hash"] = ""
    shared_data["blocks"]={}

    server_process = multiprocessing.Process(target=server, args=(mempool,))
    client_process = multiprocessing.Process(target=run_periodically, args=(mempool, shared_data,))

    server_process.start()
    client_process.start()

    server_process.join()
    client_process.join()

