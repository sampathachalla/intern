import zmq
import json
import blake3
from ecdsa import VerifyingKey, SECP256k1, BadSignatureError

def verify_transaction(transaction):
    try:
        # Ensure the transaction is a dictionary
        if isinstance(transaction, str):
            transaction = json.loads(transaction)

        # Make a copy of the transaction to avoid modifying the original
        transaction_copy = transaction.copy()

        # Extract the signature from the transaction
        signature = bytes.fromhex(transaction_copy.pop('signature'))

        # Extract the TXID from transaction details
        if 'transaction_details' in transaction_copy:
            transaction_details_copy = transaction_copy['transaction_details'].copy()
            transaction_details_copy.pop('TXID', None)
            transaction_copy['transaction_details'] = transaction_details_copy

        # Serialize the transaction data (excluding the signature and TXID)
        serialized_data = json.dumps(transaction_copy, sort_keys=True).encode('utf-8')
        
        # Hash the serialized transaction data
        transaction_hash = blake3.blake3(serialized_data).digest()
        
        # Extract the sender's public key
        public_key_hex = transaction['sender']
        public_key = VerifyingKey.from_string(bytes.fromhex(public_key_hex), curve=SECP256k1)
        
        # Verify the signature
        public_key.verify(signature, transaction_hash)
        return True
    except (BadSignatureError, KeyError, ValueError, json.JSONDecodeError) as e:
        print(f"Verification error: {e}")
        return False

# Initialize the ZeroMQ context
context = zmq.Context()

# Create a REP (reply) socket
socket = context.socket(zmq.REP)
socket.bind("tcp://*:5555")

print("Server is listening on port 5555...")

while True:
    # Wait for the next request from the client
    message = socket.recv()
    
    # Decode the message from JSON
    try:
        data = json.loads(message.decode('utf-8'))
    except json.JSONDecodeError as e:
        print(f"JSON decode error: {e}")
        response = {"status": "failure", "error": "Invalid JSON format"}
        socket.send(json.dumps(response).encode('utf-8'))
        continue
    
    print(f"Received request: {data}")

    # Verify the transaction
    is_valid = verify_transaction(data)
    print(is_valid)

    # Create a response in JSON format
    response = {
        "status": "success" if is_valid else "failure",
        "received_data": data,
        "verification": is_valid
    }
    
    # Send the response back to the client
    socket.send(json.dumps(response).encode('utf-8'))
