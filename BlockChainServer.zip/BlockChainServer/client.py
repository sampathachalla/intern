import zmq
import json

def send_json_request(data, server_address="tcp://localhost:5555"):
    # Initialize the ZeroMQ context
    context = zmq.Context()

    # Create a REQ (request) socket
    socket = context.socket(zmq.REQ)
    socket.connect(server_address)

    # Send the JSON data to the server
    socket.send(json.dumps(data).encode('utf-8'))

    # Wait for the response from the server
    message = socket.recv()

    # Decode the response from JSON
    response = json.loads(message.decode('utf-8'))

    return response


import blake3
import json
from ecdsa import SigningKey, SECP256k1
import base64
def blake3_bytes_to_string(blake3_bytes):
    # Convert bytes to base64 encoded string
    return base64.b64encode(blake3_bytes).decode('utf-8')

def blake3_string_to_bytes(blake3_string):
    # Convert base64 encoded string back to bytes
    return base64.b64decode(blake3_string.encode('utf-8'))

def serializeTransaction(transaction):
    return json.dumps(transaction, sort_keys=True).encode('utf-8')

def hashTransaction(serialized_transaction):
    return blake3.blake3(serialized_transaction).digest()

def signTransaction(transaction_hash, private_key_hex):
    private_key = SigningKey.from_string(bytes.fromhex(private_key_hex), curve=SECP256k1)
    signature = private_key.sign(transaction_hash)
    return signature

def sendTransaction(transaction, signature):
    transaction['signature'] = signature.hex()
    serialized_transaction = json.dumps(transaction)
    print("Serialized Transaction:", serialized_transaction)  # For demonstration
    return serialized_transaction

def generateKeyPair():
    private_key = SigningKey.generate(curve=SECP256k1)
    public_key = private_key.get_verifying_key()
    return public_key.to_string().hex(), private_key.to_string().hex()

def createTransaction(pub_key,prv_key,transaction_details):
    transaction = {
        "sender": pub_key,
        "transaction_details":transaction_details 
    }
    serialized_transaction = serializeTransaction(transaction)
    transaction_hash = hashTransaction(serialized_transaction)
    transaction["transaction_details"]["TXID"]=blake3_bytes_to_string(transaction_hash)
    signature = signTransaction(transaction_hash, prv_key)

    return sendTransaction(transaction, signature)


# Example usage:
public_key, private_key = generateKeyPair()
transaction_details={"work":"Policy registration"}
obj=createTransaction(public_key,private_key,transaction_details)
response = send_json_request(obj)
print(f"Received reply: {response}")


"""
if __name__ == "__main__":
    # Create some JSON data to send
    data = {
        "name": "Tanushree",
        "age": 23,
        "occupation": "student"
    }

    # Send the request and get the response
    response = send_json_request(data)
    
    print(f"Received reply: {response}")"""
