from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
import blake3
import base58
import zmq
import json
import concurrent.futures
import os
from multiprocessing import Process
import time
from datetime import datetime, timedelta
import random
import string
import secrets

ID = "node-1"

# Node Database code starts here
# Dictionary  for mapping pub_addr with wallet_id and ip_addr
pubToId = {}
wallets = {}
blocks = {}
block_hash = ""
block_counter = 0
itemsDB = {}

# dictionary list of only full node
fullNodeIps = {}

def fullNodeConstructor():
    fullNodeIps["node-1"] = "tcp://localhost:5001"
    fullNodeIps["node-2"] = "tcp://localhost:5002"
    fullNodeIps["miner-1"] = "tcp://localhost:6001"

# memory pool for storing the verified transactions
mempool = {}

# Node Database code ends here

# cryptographic helping functions start here

# Function used to get the public address from public key
def public_key_to_address(public_key):
    # Serialize public key to bytes
    public_key_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.CompressedPoint
    )

    # Hash the public key using BLAKE3
    public_key_hash = blake3.blake3(public_key_bytes).digest()

    # Encode the hash using base58
    public_address = base58.b58encode(public_key_hash).decode('utf-8')

    return public_address

# deserialize the public key 
def deserialize_public_key(public_key_pem):
    # Deserialize the PEM-encoded string back to a public key object
    public_key = serialization.load_pem_public_key(
        public_key_pem.encode('utf-8')
    )
    return public_key

# cryptographic helping functions end here


# Function for registering the wallets in the node
def wallet_register(arg, rid):
    status_code = 200
    message = "Wallet Registration Completed"
    wallet_ID = arg["walletID"]
    pub_addr = arg["pubAddr"]
    ip_addr = arg["ipAddr"]
    policy_list = arg["policyList"]
    request_list = arg["requestList"]

    if wallet_ID in wallets:
        old_pub = wallets[wallet_ID]["pubAddr"]
        del pubToId[old_pub]
        del wallets[wallet_ID]
        wallets[wallet_ID] = {"pubAddr": pub_addr, "ipAddr": ip_addr, "policyList": policy_list, "requestList": request_list}
        pubToId[pub_addr] = wallet_ID
    else:
        wallets[wallet_ID] = {"pubAddr": pub_addr, "ipAddr": ip_addr, "policyList": policy_list, "requestList": request_list}
        pubToId[pub_addr] = wallet_ID

    # Broadcasting further for all the nodes
    nodesList = list(fullNodeIps.values())
    if rid in fullNodeIps:
        temp1 = fullNodeIps[rid]
        nodesList.remove(temp1)
    if ID in fullNodeIps:
        temp2 = fullNodeIps[ID]
        nodesList.remove(temp2)
    print("Broadcasting the wallet registration to neighbouring nodes")
    # constructing the request message
    request = {"request_id": ID, "fun_code": "register", "arguments": arg}
    red_flag = server_client(request, nodesList)
    if red_flag:
        status_code = 500
        message = "Wallet Registration Failed due to internal server issue"
    if status_code == 200:
        print(f"Wallet of Id {wallet_ID} is registered in {ID}")
    return {"response_id": ID, "statusCode": status_code, "message": message}



# Function for registering the service request transaction and storing in the memorypool
def service_register(arg, rid):
    global mempool
    message = "Transaction Submitted"
    status_code = 200
    # Extracting arguments
    transaction_id = arg["TXID"]
    if status_code == 200:
        # Adding transactions to the mempool
        mempool[transaction_id] = arg
    # Broadcasting further for all the nodes
    nodesList = list(fullNodeIps.values())
    if rid in fullNodeIps:
        temp1 = fullNodeIps[rid]
        nodesList.remove(temp1)
    if ID in fullNodeIps:
        temp2 = fullNodeIps[ID]
        nodesList.remove(temp2)
    print("Broadcasting the transaction details to neighbouring nodes")
    # constructing the request message
    request = {"request_id": ID, "fun_code": "vServiceReq", "arguments": arg}
    red_flag = server_client(request, nodesList)
    if red_flag:
        status_code = 500
        message = "Transaction failed due to internal server issues"
    if status_code == 200:
        # Adding transactions to the mempool
        arg["rid"] = rid
        mempool[transaction_id] = arg
        print(f"transaction of Id {transaction_id} is registered in memory pool of {ID}")
    return {"response_id": ID, "statusCode": status_code, "message": message}

# Function for registering the policy request transaction and storing in the memorypool
def policy_register(arg, rid):
    global mempool
    message = "Policy Request Transaction Submitted"
    status_code = 200
    # Extracting arguments
    transaction_id = arg["TXID"]
    if status_code == 200:
        # Adding transactions to the mempool
        mempool[transaction_id] = arg
    # Broadcasting further for all the nodes
    nodesList = list(fullNodeIps.values())
    if rid in fullNodeIps:
        temp1 = fullNodeIps[rid]
        nodesList.remove(temp1)
    if ID in fullNodeIps:
        temp2 = fullNodeIps[ID]
        nodesList.remove(temp2)
    print("Broadcasting the transaction details to neighbouring nodes")
    # constructing the request message
    request = {"request_id": ID, "fun_code": "vPolicyReq", "arguments": arg}
    # print(nodesList)
    red_flag = server_client(request, nodesList)
    if red_flag:
        status_code = 500
        message = "Transaction failed due to internal server issues"
    if status_code == 200:
        # Adding transactions to the mempool
        mempool[transaction_id] = arg
        mempool[transaction_id]["rid"] = rid
        print(f"transaction of Id {transaction_id} is registered in memory pool of {ID}")
    # print(mempool)
    return {"response_id": ID, "statusCode": status_code, "message": message}

# main function for verifying the block
def verify_block(arg, rid):
    message = "block is accepted"
    status_code = 200
    return {"response_id": ID, "statusCode": status_code, "message": message}

# function used to send notification to the wallet
def notify_wallet(trans, rid):
    funCode = ""
    transID = trans["TXID"]
    message = f"Transaction {transID} successful"
    funCode = "transaction"
    request = {"request_id": ID, "fun_code": funCode, "arguments": trans, "message": message}
    request_message = json.dumps(request).encode('utf-8')

    # Extracting the ip address
    raddr = wallets[rid]['ipAddr']
    # Create a ZeroMQ context
    context = zmq.Context()

    # Create a REQ (request) socket
    socket1 = context.socket(zmq.REQ)
    # sending the notification to the sender
    socket1.connect(raddr)

    # Send a request to the server
    socket1.send(request_message)

    # Wait for the reply from the server
    reply = socket1.recv_string()
    print(reply)

# function used to update the mempool
def update_mempool(trans, rid):
    global mempool
    transID = trans["TXID"]
    rid = mempool[transID]["rid"]
    del mempool[transID]
    if rid in list(wallets.keys()):
        pass
        #notify_wallet(trans, rid)

# function to add the block to the blockchain
def add_block(arg, rid):
    message = "block is added"
    status_code = 200
    global block_hash
    global block_counter
    global blocks
    if block_counter == 0:
        print("block0 added")
        block_hash = f"block{block_counter}"
        blocks[block_hash] = arg
        block_counter = block_counter + 1
    else:
        print(f"block{block_counter} added")
        block_hash = f"block{block_counter}"
        block_counter = block_counter + 1
        blocks[block_hash] = arg
    # Extracting the transactions
    body = arg['body']
    tempList = list(body.keys())
    for i in tempList:
        update_mempool(body[i], rid)
    return {"response_id": ID, "statusCode": status_code, "message": message}

# function used to fetch transaction details
def fetch_details(arg, rid):
    print(f"fetching the details of transaction {arg}")
    temp_block_hash = block_hash
    trans = {}
    bingo = ""
    while (len(temp_block_hash) != 0):
        bingo = temp_block_hash
        temp_block = blocks[temp_block_hash]
        temp_block_head = temp_block["head"]
        temp_block_body = temp_block["body"]
        temp_block_hash = temp_block_head["previousBlockHash"]
        temp_block_count = temp_block_head["count"]
        if temp_block_count > 0:
            if arg in temp_block_body:
                trans = temp_block_body[arg]
                break
    
    obj={"block":bingo,"details":trans}
    status_code = 200
    return {"response_id": ID, "statusCode": status_code, "obj": obj}

# Function used to store the blockchain in the file
def store_block(ard, rid):
    data = blocks
    file_path = "node1blocks.json"
    if not os.path.exists(file_path):
        with open(file_path, 'w') as file:
            pass  # Just create the file

    # Write the dictionary to the file
    with open(file_path, 'w') as file:
        json.dump(data, file, indent=4)
    print(f'Dictionary has been stored in {file_path}')

    message = f"Blocks have been stored in the file node1blocks.json"
    status_code = 200
    return {"response_id": ID, "statusCode": status_code, "message": message}

# Client Code Starts Here
def send_request(server_address, request_message):
    context = zmq.Context()

    # Create a REQ socket to communicate with the server
    socket = context.socket(zmq.REQ)
    socket.connect(server_address)

    # Send the request to the server
    socket.send(request_message)

    # Receive the reply from the server
    reply_message = socket.recv()
    reply = json.loads(reply_message.decode('utf-8'))

    socket.close()
    context.term()
    return reply

def server_client(request, server_addresses):
    red_flag = False
    if not server_addresses:
        return red_flag

    # Construct the request message
    request_message = json.dumps(request).encode('utf-8')

    # Use ProcessPoolExecutor to send requests to multiple servers in parallel
    with concurrent.futures.ProcessPoolExecutor(max_workers=len(server_addresses)) as executor:
        futures = [executor.submit(send_request, server_address, request_message) for server_address in server_addresses]

        # Wait for all the futures to complete
        for future in concurrent.futures.as_completed(futures):
            try:
                result = future.result()
                if result['statusCode'] == 500:
                    red_flag = True
            except Exception as exc:
                print(f"Request generated an exception: {exc}")
    return red_flag

# Client Code Ends Here

# Server Code Starts Here
def worker(worker_url, worker_id):
    import json  # Ensure json is imported within the worker process
    context = zmq.Context()
    socket = context.socket(zmq.DEALER)
    socket.identity = worker_id.encode('utf-8')
    socket.connect(worker_url)

    while True:
        try:
            reply = {}
            message = socket.recv_multipart()
            client_address, empty, request = message
            data = json.loads(request.decode('utf-8'))
            fun = data["fun_code"]
            if fun == "register":
                reply = wallet_register(data["arguments"], data["request_id"])
            elif fun == "vServiceReq":
                reply = service_register(data["arguments"], data["request_id"])
            elif fun == "vPolicyReq":
                reply = policy_register(data["arguments"], data["request_id"])
            elif fun == "vBlock":
                reply = verify_block(data["arguments"], data["request_id"])
            elif fun == "addBlock":
                reply = add_block(data["arguments"], data["request_id"])
            elif fun == "store_blocks":
                reply = store_block(data["arguments"], data["request_id"])
            elif fun == "fetch_trans":
                reply = fetch_details(data["arguments"], data["request_id"])

            # Process the request
            reply_message = json.dumps(reply).encode('utf-8')

            # Send the reply back to the client via the backend
            socket.send_multipart([client_address, b'', reply_message])
        except Exception as e:
            print(f"Worker {worker_id} encountered an error: {e}")

def start_worker(worker_id):
    worker("ipc://backend.ipc", worker_id)

def server():
    print("Node-1 Started")
    context = zmq.Context()

    # Frontend socket for client communication
    frontend = context.socket(zmq.ROUTER)
    try:
        frontend.bind("tcp://*:5001")  # Changed port to 5003
    except zmq.ZMQError as e:
        print(f"Error binding frontend socket: {e}")
        return

    # Backend socket for worker communication
    backend = context.socket(zmq.DEALER)
    try:
        backend.bind("ipc://backend.ipc")
    except zmq.ZMQError as e:
        print(f"Error binding backend socket: {e}")
        frontend.close()
        context.term()
        return

    # Start a pool of worker processes
    for i in range(1):
        Process(target=start_worker, args=(f"worker-{i}",)).start()

    try:
        # Use zmq.proxy to forward messages between frontend and backend
        zmq.proxy(frontend, backend)
    except KeyboardInterrupt:
        print("Server interrupted and shutting down.")
    finally:
        frontend.close()
        backend.close()
        context.term()

# Server Code Ends Here
fullNodeConstructor()

# Check if server function is being called more than once
if __name__ == "__main__":
    if "server_function_called" not in globals():
        global server_function_called
        server_function_called = True
        server()
