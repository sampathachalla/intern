import json
import os

CUSTOMER_FILE = "customer_data.txt"

def load_customers_from_file():
    """Load customer data from a text file into a dictionary."""
    customer_database = {}
    try:
        if os.path.exists(CUSTOMER_FILE):
            with open(CUSTOMER_FILE, 'r') as file:
                for line in file:
                    customer = json.loads(line.strip())
                    customer_database[customer["customerID"]] = {
                        "name": customer["name"],
                        "phone": customer["phone"],
                        "email": customer["email"],
                        "address": customer["address"],
                        "serviceIDs": customer["serviceIDs"]
                    }
    except Exception as e:
        print(f"Error loading customers from file: {e}")
    return customer_database

def save_customer_to_file(customer_id, name, phone, email, address, service_ids):
    """Save a new customer to the text file."""
    try:
        with open(CUSTOMER_FILE, 'a') as file:
            customer = {
                "customerID": customer_id,
                "name": name,
                "phone": phone,
                "email": email,
                "address": address,
                "serviceIDs": service_ids
            }
            file.write(json.dumps(customer) + "\n")
    except Exception as e:
        print(f"Error saving customer to file: {e}")

def get_all_customers(customer_database):
    """Retrieve all customer data from the customer database."""
    try:
        return dict(customer_database)  # Convert managed dict to regular dict for serialization
    except Exception as e:
        print(f"Error retrieving all customers: {e}")
        return {"status": "error", "message": str(e)}

def add_customer_data(customer_database, customer_id, name, phone, email, address, service_ids):
    """Add customer data to the customer database and save to file."""
    try:
        if customer_id in customer_database:
            return {"status": "error", "message": "Customer ID already exists"}
        customer_database[customer_id] = {
            "name": name,
            "phone": phone,
            "email": email,
            "address": address,
            "serviceIDs": service_ids
        }
        save_customer_to_file(customer_id, name, phone, email, address, service_ids)
        return {"status": "success", "message": "Customer added"}
    except Exception as e:
        print(f"Error adding customer data: {e}")
        return {"status": "error", "message": str(e)}
    

def fetch_user_details(credentials_database, customer_database, service_database, policy_database, service_repair_database, stock_database, username):
    user_details = {
        "customer_id": None,
        "customer_name": None,
        "customer_email": None,
        "customer_address": None,
        "customer_service_list": [],
        "customer_equipment_id_list": [],
        "customer_service_repair_id_list": [],
        "equipment_details_list": [],
        "service_repair_details_list": []
    }

    # Find the user in the credentials database
    user_id = None
    for user in credentials_database.values():
        if user['username'] == username:
            user_id = user['id']
            break

    if not user_id:
        return {"status": "error", "message": "User not found"}

    # Fetch customer details
    if user_id in customer_database:
        user_details["customer_id"] = user_id
        user_details["customer_name"] = customer_database[user_id]["name"]
        user_details["customer_email"] = customer_database[user_id]["email"]
        user_details["customer_address"] = customer_database[user_id]["address"]
        user_details["customer_service_list"].extend(customer_database[user_id]["serviceIDs"])
    else:
        return {"status": "error", "message": "Customer data not found"}

    # Fetch equipment IDs and details associated with the service numbers in the customer_service_list
    service_ids = user_details["customer_service_list"]
    for service_id in service_ids:
        for equipment_id, equipment in stock_database.items():
            if equipment["serviceID"] == service_id:
                user_details["customer_equipment_id_list"].append(equipment_id)

                # Add equipment details
                equipment_details = {
                    "equipment_id": equipment_id,
                    "type": equipment["type"],
                    "health": "healthy"
                }
                user_details["equipment_details_list"].append(equipment_details)

                # Fetch associated service repair IDs and details
                service_repair_ids = equipment.get("service_repair_IDs", [])
                user_details["customer_service_repair_id_list"].extend(service_repair_ids)
                for repair_id in service_repair_ids:
                    if repair_id in service_repair_database:
                        service_repair = service_repair_database[repair_id]
                        service_repair_details = {
                            "service_repair_id": repair_id,
                            "equipment_id": service_repair["equipmentID"],
                            "technician_name": service_repair["technicianName"],
                            "technician_email": service_repair["technicianEmail"],
                            "technician_phone": service_repair["technicianPhone"],
                            "rating": service_repair["rating"],
                            "opening_date": service_repair["openingDate"],
                            "closing_date": service_repair["closingDate"],
                            "problem_description": service_repair["problemDescription"],
                            "status": service_repair["status"],
                            "equipment_type": service_repair["equipmentType"]
                        }
                        user_details["service_repair_details_list"].append(service_repair_details)
    print(user_details)

    return user_details

def fetch_customer_details(customer_id, customer_database, stock_database, service_repair_database):
    if customer_id not in customer_database:
        return None

    customer = customer_database[customer_id]
    service_ids = customer['serviceIDs']  # Assuming multiple service IDs

    equipment_details = []
    service_repair_ids = []
    service_repair_details = []

    for service_id in service_ids:
        for equipment_id, equipment in stock_database.items():
            if equipment['serviceID'] == service_id:
                equipment_details.append({
                    'equipmentID': equipment_id,
                    'type': equipment['type']
                })
                service_repair_ids.extend(equipment['service_repair_IDs'])

    for repair_id in service_repair_ids:
        if repair_id in service_repair_database:
            service_repair = service_repair_database[repair_id]
            service_repair_details.append({
                'serviceRepairID': repair_id,
                'equipmentID': service_repair['equipmentID'],
                'technicianName': service_repair['technicianName'],
                'technicianEmail': service_repair['technicianEmail'],
                'technicianPhone': service_repair['technicianPhone'],
                'rating': service_repair['rating'],
                'openingDate': service_repair['openingDate'],
                'closingDate': service_repair['closingDate'],
                'problemDescription': service_repair['problemDescription'],
                'issue': service_repair['issue'],
                'status': service_repair['status'],
                'equipmentType': service_repair['equipmentType']
            })

    return {
        'name': customer['name'],
        'email': customer['email'],
        'address': customer['address'],
        'phone': customer['phone'],
        'equipmentDetails': equipment_details,
        'serviceRepairIDs': service_repair_ids,
        'serviceRepairDetails': service_repair_details
    }




