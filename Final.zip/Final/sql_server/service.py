import json
import os
import random

from stock import update_stock
from policy import add_policy_data
from customer import add_customer_data

SERVICE_FILE = "service_data.txt"

def load_services_from_file():
    """Load service data from a text file into a dictionary."""
    service_database = {}
    try:
        if os.path.exists(SERVICE_FILE):
            with open(SERVICE_FILE, 'r') as file:
                for line in file:
                    service = json.loads(line.strip())
                    service_database[service["serviceID"]] = service["policyNumbers"]
    except Exception as e:
        print(f"Error loading services from file: {e}")
    return service_database

def save_service_to_file(service_id, policy_numbers):
    """Save a new service to the text file."""
    try:
        with open(SERVICE_FILE, 'a') as file:
            service = {
                "serviceID": service_id,
                "policyNumbers": policy_numbers
            }
            file.write(json.dumps(service) + "\n")
    except Exception as e:
        print(f"Error saving service to file: {e}")

def get_all_services(service_database):
    """Retrieve all service data from the service database."""
    try:
        return dict(service_database)  # Convert managed dict to regular dict for serialization
    except Exception as e:
        print(f"Error retrieving all services: {e}")
        return {"status": "error", "message": str(e)}

def add_service_data(service_database, service_id, policy_numbers):
    """Add service data to the service database and save to file."""
    try:
        if service_id in service_database:
            return {"status": "error", "message": "Service ID already exists"}
        service_database[service_id] = policy_numbers
        save_service_to_file(service_id, policy_numbers)
        return {"status": "success", "message": "Service added"}
    except Exception as e:
        print(f"Error adding service data: {e}")
        return {"status": "error", "message": str(e)}

individual_list=["router","modem"]
office_list=["router","modem","laptop"]
mini_hub_list=["router","modem","laptop","storage"]

def genServiceId():
    prefix = "s"
    random_number = random.randint(1000, 9999)  # Generates a random four-digit number
    return f"{prefix}{random_number}"

def genPoicyId():
    prefix = "p"
    random_number = random.randint(100000, 999999)  # Generates a random six-digit number
    return f"{prefix}{random_number}"

def add_service(service_database,stock_database,policy_database,customer_database,credentials_database,data):
    print("called the fucntion")
    #Fetching the requied information from the payload
    customer_name=data["username"]
    customer_email=data["email"]
    customer_phone=data["phone"]
    customer_address=data["address"]
    customer_ID=credentials_database[customer_name]["id"]
    service_id=genServiceId()
    #Fetching the equipments details from the stock database
    service_type=data["service_type"]
    if service_type=="individual":
        equipment_type_list=individual_list
    if service_type=="mini-hub":
        equipment_type_list=mini_hub_list
    if service_type=="office":
        equipment_type_list=office_list
    stockIds=list(stock_database.keys())
    eq_policy_dict={}
    for eqType in equipment_type_list:
        for i in stockIds:
            if stock_database[i]["type"]==eqType and stock_database[i]["status"]=="warehouse":
                eq_policy_dict[i]=genPoicyId()
                break
    
    print("customer name: ",customer_name)
    print("customer phone: ",customer_phone)
    print("customer email: ",customer_email)
    print("customer address: ",customer_address)
    print("customer Id: ",customer_ID)
    print("service id: ",service_id)
    print(eq_policy_dict)
    
    #updating the stock databse
    eqIDs=list(eq_policy_dict.keys())
    for i in eqIDs:
        stock_database[i]["status"]="customer"
        stock_database[i]["serviceID"]=service_id
        stock_database[i]["policyNumbers"].append(eq_policy_dict[i])
        update_stock(stock_database,i,"customer",service_id)
    #adding data to the customer database
    service_ids=[]
    service_ids.append(service_id)
    add_customer_data(customer_database, customer_ID, customer_name, customer_phone, customer_email, customer_address, service_ids)
    #adding data to the policy database
    for i in eqIDs:
        add_policy_data(policy_database,eq_policy_dict[i], i, [])
    #adding data to the service database
    add_service_data(service_database, service_id, list(eq_policy_dict.values()))

    return {"status": "success", "message": "service added successfully"}

