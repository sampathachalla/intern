from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import utils
from binascii import unhexlify
from datetime import datetime
from threading import Thread
from datetime import datetime, timedelta
import secrets
import string
import random
import blake3
import base58
import time
import uuid
import json
import zmq
import os

ID="wallet-1"
privateKey=""
publicKey=""
transaction_counter=1
policy_dict={}
policy_txn={}
service_repair_txn={}
transactions=[]

global temp

# wallet client code starts here
def client(request):
    context = zmq.Context()

    # Create a REQ socket to communicate with the server
    socket = context.socket(zmq.REQ)
    socket.connect("tcp://localhost:5001")

    # Create a request message
    #request = {"request": "Hello"}
    request_message = json.dumps(request).encode('utf-8')

    # Send the request to the server
    print("Sending request to server...")
    socket.send(request_message)

    # Receive the reply from the server
    reply_message = socket.recv()
    reply = json.loads(reply_message.decode('utf-8'))
    return reply
#wallet client code ends here


#Wallet creation and Registration code starts here
#Function used to create private and public key
def generate_key_pair():
    # Generate ECC key pair
    private_key = ec.generate_private_key(ec.SECP256R1())
    public_key = private_key.public_key()
    
    return private_key, public_key

#Function used to get the public address from public key    
def public_key_to_address(public_key):
    # Serialize public key to bytes
    public_key_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.CompressedPoint
    )
    
    # Hash the public key using BLAKE3
    public_key_hash = blake3.blake3(public_key_bytes).digest()
    
    # Encode the hash using base58
    public_address = base58.b58encode(public_key_hash).decode('utf-8')
    
    return public_address

#Function used to create the wallet
def create_wallet():
    global privateKey
    global publicKey
    privateKey,publicKey=generate_key_pair()
    public_address=public_key_to_address(publicKey)
    ip_address="tcp://localhost:4001"
    #print(f"wallet of id {wallet_id} created succesfully")
    return {"walletID":ID,"pubAddr":public_address,"ipAddr":ip_address,"policyList":[],"requestList":[]}

#Function used to register the wallet in the network
def wallet_registration():
    walletInfo=create_wallet()
    request={"request_id":ID,"fun_code":"register","arguments":walletInfo}
    reply=client(request)
    #print(f"{reply['message']}")

#Wallet creation and Registration code ends here


def generate_txid(length=16):
    characters = string.ascii_letters + string.digits
    return ''.join(secrets.choice(characters) for _ in range(length))

#Function for registering the policy in the blockchain
def cook_policy():
    Txid=generate_txid()
    obj={"work":"Policy registration","TXID":Txid}
    request={"request_id":ID,"fun_code":"vPolicyReq","arguments":obj}
    reply2=client(request)
    print(reply2)
    return Txid

    

def cook_service_repair():
    Txid=generate_txid()
    obj={"work":"Service Repair Registration","TXID":Txid}
    request={"request_id":ID,"fun_code":"vServiceReq","arguments":obj}
    reply=client(request)
    print(reply)
    return Txid

def store_block():
    obj={}
    request={"request_id":ID,"fun_code":"store_blocks","arguments":obj}
    reply=client(request)
    print(reply)

def fetch_trans(TXID):
    obj={}
    request={"request_id":ID,"fun_code":"fetch_trans","arguments":TXID}
    reply=client(request)
    print(reply)


while(True):
    print("Enter 1 for wallet registration")
    print("enter 2 for policy registration")
    print("Enter 3 for the service repair registration")
    print("enter 4 for fetching transaction")
    print("Enter 5 for storing the transaction")
    inp=int(input("Enter number for the oepration: "))
    if inp==1:
        wallet_registration()
    elif inp==2:
        temp=cook_policy()
    elif inp==3:
        temp=cook_service_repair()
    elif inp==5:
        store_block()
    elif inp==4:
        temp="6B9eUYLPXMZhe85X"
        fetch_trans(temp)
    









