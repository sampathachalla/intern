import zmq
import json
from flask import Blueprint, jsonify, request

agent_blueprint = Blueprint('agent', __name__)

#Function used to send and receive the request to the server
def client(action, data=None):
    context = zmq.Context()

    # Create a REQ (Request) socket
    socket = context.socket(zmq.REQ)
    socket.connect("tcp://localhost:5560")  # Connect to the server

    # Create a request message
    request_message = {
        "action": action
    }
    if data:
        request_message["data"] = data
    request_json = json.dumps(request_message).encode('utf-8')

    try:
        # Send the request to the server
        print(f"Sending request for {action} to server...")
        socket.send(request_json)

        # Receive the reply from the server
        reply = socket.recv()
        reply_message = json.loads(reply.decode('utf-8'))
        return reply_message
    except Exception as e:
        print(f"Client encountered an error: {e}")
        return None
    finally:
        socket.close()
        context.term()

#Function which is used to fetch the equipment details from the server 
@agent_blueprint.route('/equipment', methods=['GET'])
def get_equipment_details():
    action = "get_all_stock"  
    equipment_details_dict = client(action)
    if not equipment_details_dict:
        return jsonify({"error": "No data found"}), 404
    
    
    equipment_details_list = [
        {"equipmentID": key, **value} 
        for key, value in equipment_details_dict.items()
    ]
    
    return jsonify(equipment_details_list)
#Function used to fetch the details of all the pending orders of the users from the server
@agent_blueprint.route('/pending', methods=['GET'])
def get_pending_service_repairs():
    action = "get_pending_service_repairs_data"  
    pending_details_dict = client(action)
    """if not pending_details_dict:
        return jsonify({"error": "No data found"}), 404"""
    
    
    pending_details_list = [
        {"service_repair_id": key, **value}
        for key, value in pending_details_dict.items()
    ]
    
    return jsonify(pending_details_list)

#Function used to fetch the details of all the ongoing orders of the users from the server
@agent_blueprint.route('/ongoing', methods=['GET'])
def get_ongoing_service_repairs():
    action = "get_ongoing_service_repairs_data"  
    ongoing_details_dict = client(action)
    """if not ongoing_details_dict:
        return jsonify({"error": "No data found"}), 404"""
    
    
    ongoing_details_list = [
        {"service_repair_id": key, **value}
        for key, value in ongoing_details_dict.items()
    ]
    
    return jsonify(ongoing_details_list)

#Function used to fetch the details of all the completed orders of the users from the server
@agent_blueprint.route('/completed', methods=['GET'])
def get_completed_service_repairs():
    action = "get_completed_service_repairs_data"  
    completed_details_dict = client(action)
    """if not completed_details_dict:
        return jsonify({"error": "No data found"}), 404"""
    
    
    completed_details_list = [
        {"service_repair_id": key, **value}
        for key, value in completed_details_dict.items()
    ]
    
    return jsonify(completed_details_list)

#Functions used to call the server to get the equipment counts starts here
@agent_blueprint.route('/count_total_equipment', methods=['GET'])
def count_total_equipment_route():
    action = "count_total_equipment"
    total_equipment = client(action)
    if not total_equipment:
        return jsonify({"error": "No data found"}), 404

    return jsonify(total_equipment)

@agent_blueprint.route('/count_equipment_by_type', methods=['GET'])
def count_equipment_by_type_route():
    action = "count_equipment_by_type"
    equipment_by_type = client(action)
    if not equipment_by_type:
        return jsonify({"error": "No data found"}), 404

    type_counts = [{"type": k, "warehouse": v.get('warehouse', 0), "customer": v.get('customer', 0), "repair": v.get('repair', 0), "discarded": v.get('discarded', 0)} for k, v in equipment_by_type.items()]
    status_counts = equipment_by_type.get('status_counts', {})
    
    return jsonify({
        "type_counts": type_counts,
        "status_counts": status_counts
    })
#Functions used to call the server to get the equipment counts ends here

#Function used to get the technician details from the server
@agent_blueprint.route('/technicians', methods=['GET'])
def get_all_technicians_route():
    action = "get_all_technicians"
    technician_details_list = client(action)
    if not technician_details_list:
        return jsonify({"error": "No data found"}), 404

    return jsonify(technician_details_list)

#Function used to get the techician IDs from the server which is used for assigning the service repair fucntionality
@agent_blueprint.route('/technicianID', methods=['GET'])
def get_all_technicianID_route():
    action = "get_all_technician_id"
    technician_details_list = client(action)
    if not technician_details_list:
        return jsonify({"error": "No data found"}), 404

    return jsonify(technician_details_list)

#Fucntion used to get the list of customers with minimal information
@agent_blueprint.route('/customers', methods=['GET'])
def get_all_customers_route():
    action = "get_all_customers"
    customer_details_dict = client(action)
    if not customer_details_dict:
        return jsonify({"error": "No data found"}), 404

    
    customer_details_list = [
        {"customerId": key, **value}
        for key, value in customer_details_dict.items()
    ]

    return jsonify(customer_details_list)

#Function used to get the techcian performance details
@agent_blueprint.route('/technician_performance', methods=['GET'])
def get_technician_performance():
    technician_id = request.args.get('technicianId')
    if not technician_id:
        return jsonify({"error": "Technician ID is required"}), 400
    
    action = "calculate_technician_performance"
    data = {"id": technician_id}
    performance_details = client(action, data)
    if not performance_details:
        return jsonify({"error": "No data found"}), 404
    
    return jsonify(performance_details)

#Function used to get the individual customer details
@agent_blueprint.route('/customer_details', methods=['GET'])
def get_customer_details():
    customer_id = request.args.get('customerId')
    if not customer_id:
        return jsonify({"error": "Customer ID is required"}), 400
    
    action = "fetch_customer_details"
    data = {"id": customer_id}
    customer_details = client(action, data)
    if not customer_details:
        return jsonify({"error": "No data found"}), 404
    
    return jsonify(customer_details)

#Function used to get the individual equipment details
@agent_blueprint.route('/equipment_details', methods=['GET'])
def get_equipment_details_by_id():
    equipment_id = request.args.get('equipmentId')
    action = "fetch_equipment_details"
    equipment_details = client(action, {"id": equipment_id})
    if not equipment_details:
        return jsonify({"error": "No data found"}), 404
    
    return jsonify(equipment_details)

#Function used to assigning the techinician to the service repair
@agent_blueprint.route('/assign', methods=['POST'])
def assign_repair_to_technician():
    data = request.get_json()
    technician_id = data.get("technicianId")
    repair_ids = data.get("repairIds")

    if not technician_id or not repair_ids:
        return jsonify({"error": "Technician ID and repair IDs are required"}), 400

    action = "assign_repair_to_technician"
    request_data = {
        "technicianId": technician_id,
        "repairIds": repair_ids
    }

    response = client(action, request_data)
    if not response:
        return jsonify({"error": "Assignment failed"}), 500

    return jsonify(response)

#Function used for signup and login as agent
def authenticate_agent(users, username, password):
    for user in users:
        if user['userType'] == 'agent' and user['username'] == username and user['password'] == password:
            return True
    return False
