import zmq
import json
from flask import Blueprint, jsonify, request

technician_blueprint = Blueprint('technician', __name__)

#function used for sending ans receiving the requests to the server
def client(action, data=None):
    context = zmq.Context()

    
    socket = context.socket(zmq.REQ)
    socket.connect("tcp://localhost:5560") 

    
    request_message = {
        "action": action
    }
    if data:
        request_message["data"] = data
    request_json = json.dumps(request_message).encode('utf-8')

    try:
        
        print(f"Sending request for {action} to server...")
        socket.send(request_json)

        
        reply = socket.recv()
        reply_message = json.loads(reply.decode('utf-8'))
        return reply_message
    except Exception as e:
        print(f"Client encountered an error: {e}")
        return None
    finally:
        socket.close()
        context.term()

#Function used to fetch the pending orders of the particular technician from the server
@technician_blueprint.route('/pending', methods=['GET'])
def get_technician_pending_service_repairs():
    username = request.args.get('username')
    action = "get_all_service_repairs"
    service_repairs_dict = client(action)
    if not service_repairs_dict:
        return jsonify({"error": "No data found"}), 404
    
    
    pending_details_list = [
        {"service_repair_id": key, **value}
        for key, value in service_repairs_dict.items()
        if value["status"] == "pending" and value["technicianName"] == username
    ]
    
    return jsonify(pending_details_list)

#Function used to fetch the ongoing orders of the particular technician from the server
@technician_blueprint.route('/ongoing', methods=['GET'])
def get_technician_ongoing_service_repairs():
    username = request.args.get('username')
    action = "get_all_service_repairs"
    service_repairs_dict = client(action)
    if not service_repairs_dict:
        return jsonify({"error": "No data found"}), 404
    
    
    ongoing_details_list = [
        {"service_repair_id": key, **value}
        for key, value in service_repairs_dict.items()
        if value["status"] == "ongoing" and value["technicianName"] == username
    ]
    
    return jsonify(ongoing_details_list)

#Function used to fetch the completed orders of the particular technician from the server
@technician_blueprint.route('/completed', methods=['GET'])
def get_technician_completed_service_repairs():
    username = request.args.get('username')
    action = "get_all_service_repairs"
    service_repairs_dict = client(action)
    if not service_repairs_dict:
        return jsonify({"error": "No data found"}), 404
    
    
    completed_details_list = [
        {"service_repair_id": key, **value}
        for key, value in service_repairs_dict.items()
        if value["status"] == "completed" and value["technicianName"] == username
    ]
    
    return jsonify(completed_details_list)

#Function used to send the request of placing order to the server and getting the response
@technician_blueprint.route('/order_parts', methods=['POST'])
def order_parts():
    data = request.get_json()
    action = "store_order_parts"
    result = client(action, data)
    if result and result.get("status") == "success":
        return jsonify({"message": "Order placed successfully"}), 200
    else:
        return jsonify({"error": "Failed to place order"}), 500

#Function used get the list of order parts from the server
@technician_blueprint.route('/order_parts', methods=['GET'])
def get_order_parts():
    action = "get_all_order_parts"
    order_parts_dict = client(action)
    if not order_parts_dict:
        return jsonify({"error": "No data found"}), 404
    
    return jsonify(order_parts_dict)

#Function used to send the closing the service repair to the server
@technician_blueprint.route('/close_service_repair', methods=['POST'])
def close_service_repair():
    data = request.get_json()["data"]  
    action = "close_service_repair"
    result = client(action, data)
    if result and result.get("status") == "success":
        return jsonify({"message": "Service repair closed successfully"}), 200
    else:
        return jsonify({"error": "Failed to close service repair"}), 500


#Function used to authicate the login as a technician
def authenticate_technician(users, username, password):
    for user in users:
        if user['userType'] == 'technician' and user['username'] == username and user['password'] == password:
            return True
    return False
