# __init__.py
from flask import Flask
from flask_cors import CORS
from .auth import auth_blueprint
from .agent import agent_blueprint
from .technician import technician_blueprint
from .user import user_blueprint

def create_app():
    app = Flask(__name__)
    CORS(app)  # Enable CORS for all routes
    
    # Register blueprints
    app.register_blueprint(auth_blueprint, url_prefix='/api/auth')
    app.register_blueprint(agent_blueprint, url_prefix='/api/agent')
    app.register_blueprint(technician_blueprint, url_prefix='/api/technician')
    app.register_blueprint(user_blueprint, url_prefix='/api/user')

    return app
