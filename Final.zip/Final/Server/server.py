import zmq
import json
from policy import load_policies_from_file, get_all_policies, update_policy_data
from service import load_services_from_file, get_all_services,add_service
from customer import load_customers_from_file, get_all_customers, fetch_user_details, fetch_customer_details
from stock import load_stock_from_file, get_all_stock, count_total_equipment, count_equipment_by_type, fetch_equipment_details, update_stock_repair_data
from service_repair import load_service_repairs_from_file, get_all_service_repairs, get_pending_service_repairs_data, get_completed_service_repairs_data, get_ongoing_service_repairs_data, addServiceRepair,closeServiceRepair,updateRepairStatus,updateRepairRating,updateTechnician
from technician import load_order_parts_from_file, store_order_parts, get_all_order_parts, load_technicians_from_file, get_all_technicians, calculate_technician_performance,get_all_technicians_ID
from credentials import load_credentials, add_credential, verify_credential
from layered import wallet_registration, multi_load

def handle_request(data,temp_policy_database, policy_database, service_database, customer_database, stock_database, temp_service_repair_database,service_repair_database, temp_order_parts_database,order_parts_database, credentials_database, technician_database):
    if 'action' in data:
        if data['action'] == 'get_all_policies':
            return get_all_policies(policy_database)
        elif data['action'] == 'get_all_services':
            return get_all_services(service_database)
        elif data['action'] == 'get_all_customers':
            return get_all_customers(customer_database)
        elif data['action'] == 'get_all_stock':
            return get_all_stock(stock_database)
        elif data['action'] == 'get_all_service_repairs':
            service_repair_database=multi_load(temp_service_repair_database)
            return get_all_service_repairs(service_repair_database)
        elif data['action'] == 'get_pending_service_repairs_data':
            service_repair_database=multi_load(temp_service_repair_database)
            return get_pending_service_repairs_data(service_repair_database)
        elif data['action'] == 'get_ongoing_service_repairs_data':
            service_repair_database=multi_load(temp_service_repair_database)
            return get_ongoing_service_repairs_data(service_repair_database)
        elif data['action'] == 'get_completed_service_repairs_data':
            service_repair_database=multi_load(temp_service_repair_database)
            return get_completed_service_repairs_data(service_repair_database)
        elif data['action'] == 'get_all_order_parts':
            return get_all_order_parts(temp_order_parts_database)
        elif data['action'] == 'store_order_parts':
            return store_order_parts(order_parts_database,data["data"],temp_order_parts_database)
        elif data['action'] == 'count_total_equipment':
            return count_total_equipment(stock_database)
        elif data['action'] == 'count_equipment_by_type':
            return count_equipment_by_type(stock_database)
        elif data['action'] == 'add_credential':
            add_credential(credentials_database, data['usertype'], data['username'], data['password'])
            return {"status": "success", "message": "Credential added"}
        elif data['action'] == 'verify_credential':
            is_verified = verify_credential(credentials_database, data['username'], data['password'], data['usertype'])
            return {"status": "success", "verified": is_verified}
        elif data['action'] == 'load_credentials':
            return {"status": "success", "data": list(credentials_database.values())}
        elif data['action'] == 'fetch_user_details':
            service_repair_database=multi_load(temp_service_repair_database)
            return fetch_user_details(
                credentials_database, customer_database, service_database, 
                policy_database, service_repair_database, stock_database, 
                data['username']
            )
        elif data['action'] == 'get_all_technicians':
            return get_all_technicians(technician_database)
        elif data['action'] == 'calculate_technician_performance':
            technician_id = data['data']['id']
            service_repair_database=multi_load(temp_service_repair_database)
            return calculate_technician_performance(technician_id, service_repair_database, technician_database, order_parts_database)
        elif data['action'] == 'fetch_customer_details':
            customer_id = data['data']['id']
            service_repair_database=multi_load(temp_service_repair_database)
            return fetch_customer_details(customer_id, customer_database, stock_database, service_repair_database)
        elif data['action'] == 'fetch_equipment_details':
            equipment_id = data['data']['id']
            service_repair_database=multi_load(temp_service_repair_database)
            return fetch_equipment_details(equipment_id, stock_database, service_repair_database, customer_database)
        elif data['action'] == 'add_service_repair':
            EqId = data['data']["equipment_id"]
            description = data['data']["problem_description"]
            service_repair_database=multi_load(temp_service_repair_database)
            response=addServiceRepair(policy_database, customer_database, stock_database, technician_database, service_repair_database, EqId, description,temp_service_repair_database)
            return response
        elif data['action'] == 'close_service_repair':
            #print(data)
            issue = data['data']["issue"]
            service_repair_id = data['data']["service_repair_id"]
            service_repair_database=multi_load(temp_service_repair_database)
            response=closeServiceRepair(service_repair_database,stock_database,service_repair_id,issue,temp_service_repair_database)
            #print(service_repair_database)
            return response
        elif data["action"]=="add_service":
            response=add_service(service_database,stock_database,policy_database,customer_database,credentials_database,data,temp_policy_database)
            #print(stock_database)
            return response
        elif data["action"]=="add_rating":
            service_repair_database=multi_load(temp_service_repair_database)
            response=updateRepairRating(service_repair_database,data["service_repair_id"],data["rating"],temp_service_repair_database)
            #print(service_repair_database)
            return response
        elif data["action"]=="get_all_technician_id":
            response=get_all_technicians_ID(technician_database)
            return response
        elif data["action"]=="assign_repair_to_technician":
            service_repair_database=multi_load(temp_service_repair_database)
            technicianID=data["data"]["technicianId"]
            repair_list=data["data"]["repairIds"]
            response=updateTechnician(technician_database,service_repair_database,repair_list,technicianID,temp_service_repair_database)
            return response
        else:
            return {"status": "error", "message": "Invalid action"}
    else:
        return {"status": "error", "message": "Invalid request"}

def server():
    print("Node-1 Started")
    wallet_registration()
    context = zmq.Context()
    policy_database = load_policies_from_file()  # Load policies from file into a dictionary
    service_database = load_services_from_file()  # Load services from file into a dictionary
    customer_database = load_customers_from_file()  # Load customers from file into a dictionary
    stock_database = load_stock_from_file()  # Load stock from file into a dictionary
    technician_database = load_technicians_from_file()  # Load technicians from file into a dictionary
    credentials_database = {cred['username']: cred for cred in load_credentials('credentials_data.txt')}  # Load credentials from file into a dictionary
    temp_service_repair_database={}
    service_repair_database={}
    order_parts_database={}
    temp_order_parts_database={}
    temp_policy_database={}

    
    try:
        # Frontend socket for client communication
        frontend = context.socket(zmq.ROUTER)
        frontend.bind("tcp://*:5560")

        while True:
            message = frontend.recv_multipart()
            client_address, empty, request = message
            data = json.loads(request.decode('utf-8'))
            print(f"Received request: {data}")

            response = handle_request(data,temp_policy_database, policy_database, service_database, customer_database, stock_database,temp_service_repair_database, service_repair_database, temp_order_parts_database,order_parts_database, credentials_database, technician_database)

            reply_message = json.dumps(response).encode('utf-8')
            frontend.send_multipart([client_address, b'', reply_message])

    except zmq.ZMQError as e:
        print(f"ZMQ error: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")
    finally:
        frontend.close()
        context.term()
        print("Server shut down")

if __name__ == "__main__":
    server()
