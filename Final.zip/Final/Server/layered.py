from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import utils
from binascii import unhexlify
from datetime import datetime
from threading import Thread
from datetime import datetime, timedelta
import secrets
import string
import random
import blake3
import base58
import time
import uuid
import json
import zmq
import os

ID = "wallet-1"
privateKey = ""
publicKey = ""
transaction_counter = 1
policy_dict = {}
policy_txn = {}
service_repair_txn = {}
transactions = []

global temp

# Wallet client code starts here
def client(request):
    context = zmq.Context()

    # Create a REQ socket to communicate with the server
    socket = context.socket(zmq.REQ)
    socket.connect("tcp://localhost:5001")

    # Create a request message
    request_message = json.dumps(request).encode('utf-8')

    # Send the request to the server
    print("Sending request to server...")
    socket.send(request_message)

    # Receive the reply from the server
    reply_message = socket.recv()
    reply = json.loads(reply_message.decode('utf-8'))
    return reply
# Wallet client code ends here

# Wallet creation and Registration code starts here
# Function used to create private and public key
def generate_key_pair():
    # Generate ECC key pair
    private_key = ec.generate_private_key(ec.SECP256R1())
    public_key = private_key.public_key()
    
    return private_key, public_key

# Function used to get the public address from public key    
def public_key_to_address(public_key):
    # Serialize public key to bytes
    public_key_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.CompressedPoint
    )
    
    # Hash the public key using BLAKE3
    public_key_hash = blake3.blake3(public_key_bytes).digest()
    
    # Encode the hash using base58
    public_address = base58.b58encode(public_key_hash).decode('utf-8')
    
    return public_address

# Function used to create the wallet
def create_wallet():
    global privateKey
    global publicKey
    privateKey, publicKey = generate_key_pair()
    public_address = public_key_to_address(publicKey)
    ip_address = "tcp://localhost:4001"
    return {"walletID": ID, "pubAddr": public_address, "ipAddr": ip_address, "policyList": [], "requestList": []}

# Function used to register the wallet in the network
def wallet_registration():
    walletInfo = create_wallet()
    request = {"request_id": ID, "fun_code": "register", "arguments": walletInfo}
    reply = client(request)
# Wallet creation and Registration code ends here

def generate_txid(length=16):
    characters = string.ascii_letters + string.digits
    return ''.join(secrets.choice(characters) for _ in range(length))

# Function for registering the policy in the blockchain
def cook_policy():
    while True:
        Txid = generate_txid()
        obj = {"work": "Policy registration", "TXID": Txid}
        request = {"request_id": ID, "fun_code": "vPolicyReq", "arguments": obj}
        reply2 = client(request)
        print("Policy registration response:", reply2)
        time.sleep(2)
        
        if reply2["statusCode"] == 200:
            fetch_reply = fetch_trans(Txid)
            if fetch_reply["block"] != "block0":
                print("Transaction verified:")
                return Txid
            else:
                print("Transaction in Block 0, resubmitting...")
        else:
            print("Policy registration failed, resubmitting...")

# Function for registering the service repair in the blockchain
def cook_service_repair(obj):
    while True:
        print("called cook service repair")
        Txid = generate_txid()
        obj["TXID"] = Txid
        request = {"request_id": ID, "fun_code": "vServiceReq", "arguments": obj}
        reply = client(request)
        print("Service repair response:", reply)
        time.sleep(2)
        if reply["statusCode"] == 200:
            fetch_reply = fetch_trans(Txid)
            if fetch_reply["block"] != "block0":
                print("Transaction verified:")
                return Txid
            else:
                print("Transaction in Block 0, resubmitting...")
        else:
            print("Service repair registration failed, resubmitting...")


# Function used to store the blockchain data in the file
def store_block():
    obj = {}
    request = {"request_id": ID, "fun_code": "store_blocks", "arguments": obj}
    reply = client(request)

# Function used to fetch the transaction from the blockchain
def fetch_trans(TXID):
    request = {"request_id": ID, "fun_code": "fetch_trans", "arguments": TXID}
    reply = client(request)
    return reply["obj"]

# Function used to fetch the data from the blockchain and load to the local database
def single_load(TXID):
    ans = fetch_trans(TXID)
    block = ans["block"]
    if block == "block0":
        return {}
    obj = ans["details"]
    policyNumber = obj["policyID"]
    serviceID = obj["serviceID"]
    equipmentID = obj["EqId"]
    customerName = obj["customer_name"]
    customerPhone = obj["customer_phone"]
    customerEmail = obj["customer_email"]
    customerAddress = obj["customer_address"]
    technicianName = obj["technician_name"]
    technicianEmail = obj["technician_email"]
    technicianPhone = obj["technician_phone"]
    rating = obj["rating"]
    openingDate = obj["openingDate"]
    closingDate = obj["closingDate"]
    problemDescription = obj["description"]
    issue = obj["issue"]
    status = obj["status"]
    equipmentType = obj["EqType"]

    return {"policyNumber": policyNumber, "serviceID": serviceID, "equipmentID": equipmentID, "customerName": customerName, "customerPhone": customerPhone,
            "customerEmail": customerEmail, "customerAddress": customerAddress, "technicianName": technicianName, "technicianEmail": technicianEmail, 
            "technicianPhone": technicianPhone, "rating": rating, "openingDate": openingDate, "closingDate": closingDate, "problemDescription": problemDescription, 
            "issue": issue, "status": status, "equipmentType": equipmentType}

#Function used to get the full list of all the service repair details from the blockchain using the metadata present in the local dictionary database
def multi_load(service_repair_database):
    print("Called multiload")
    service_repair_dict = {}
    for i in list(service_repair_database.keys()):
        print(f"Getting details of {i}")
        service_repair_dict[i] = single_load(service_repair_database[i])
    return service_repair_dict

#Function to get the invidual details of single order from the blockchain
def single_load_order(TXID):
    ans = fetch_trans(TXID)
    block = ans["block"]
    if block == "block0":
        return {}
    obj = ans["details"]
    return obj

#Function used to get all the detaisl of orders from the block chain using the metadata from the local dictionary database
def multi_load_order(order_part_database):
    print("Called multiload")
    order_part_dict = {}
    for i in list(order_part_database.keys()):
        print(f"Getting details of {i}")
        order_part_dict[i] = single_load_order(order_part_database[i])
    return order_part_dict
