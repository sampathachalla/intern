import json
import os
import random
from datetime import datetime, timedelta
from policy import update_policy_data
from stock import update_stock_repair_data,update_stock
from layered import cook_service_repair,wallet_registration,single_load
import time


SERVICE_REPAIR_FILE = "service_repair_data.txt"

#Function used to load the service repair details from the file to the dictionary database
def load_service_repairs_from_file():
    """Load service repair data from a text file into a dictionary."""
    service_repair_database = {}
    try:
        if os.path.exists(SERVICE_REPAIR_FILE):
            with open(SERVICE_REPAIR_FILE, 'r') as file:
                for line in file:
                    repair = json.loads(line.strip())
                    service_repair_database[repair["service_repair_id"]] = {
                        "policyNumber": repair["policyNumber"],
                        "serviceID": repair["serviceID"],
                        "equipmentID": repair["equipmentID"],
                        "customerName": repair["customerName"],
                        "customerPhone": repair["customerPhone"],
                        "customerEmail": repair["customerEmail"],
                        "customerAddress": repair["customerAddress"],
                        "technicianName": repair["technicianName"],
                        "technicianEmail": repair["technicianEmail"],
                        "technicianPhone": repair["technicianPhone"],
                        "rating": repair["rating"],
                        "openingDate": repair["openingDate"],
                        "closingDate": repair["closingDate"],
                        "problemDescription": repair["problemDescription"],
                        "issue": repair["issue"],
                        "status": repair["status"],
                        "equipmentType": repair["equipmentType"]
                    }
    except Exception as e:
        print(f"Error loading service repairs from file: {e}")
    return service_repair_database

#Function used to store the service repair details to the file
def save_service_repair_to_file(service_repair_id, policy_number, service_id, equipment_id, customer_name, customer_phone, customer_email, customer_address, technician_name, technician_email, technician_phone, rating, opening_date, closing_date, problem_description, issue, status, equipment_type):
    """Save a new service repair to the text file."""
    try:
        with open(SERVICE_REPAIR_FILE, 'a') as file:
            repair = {
                "service_repair_id": service_repair_id,
                "policyNumber": policy_number,
                "serviceID": service_id,
                "equipmentID": equipment_id,
                "customerName": customer_name,
                "customerPhone": customer_phone,
                "customerEmail": customer_email,
                "customerAddress": customer_address,
                "technicianName": technician_name,
                "technicianEmail": technician_email,
                "technicianPhone": technician_phone,
                "rating": rating,
                "openingDate": opening_date,
                "closingDate": closing_date,
                "problemDescription": problem_description,
                "issue": issue,
                "status": status,
                "equipmentType": equipment_type
            }
            file.write(json.dumps(repair) + "\n")
            print("write to the file")
    except Exception as e:
        print(f"Error saving service repair to file: {e}")
#Function used to get the list of service repairs
def get_all_service_repairs(service_repair_database):
    """Retrieve all service repair data from the service repair database."""
    try:
        return dict(service_repair_database)  # Convert managed dict to regular dict for serialization
    except Exception as e:
        print(f"Error retrieving all service repairs: {e}")
        return {"status": "error", "message": str(e)}

#Function used to store the service repair details to the local dictionary database
def add_service_repair_data(service_repair_database, service_repair_id, policy_number, service_id, equipment_id, customer_name, customer_phone, customer_email, customer_address, technician_name, technician_email, technician_phone, rating, opening_date, closing_date, problem_description, issue, status, equipment_type):
    """Add service repair data to the service repair database and save to file."""
    try:
        if service_repair_id in service_repair_database:
            return {"status": "error", "message": "Service repair ID already exists"}
        service_repair_database[service_repair_id] = {
            "policyNumber": policy_number,
            "serviceID": service_id,
            "equipmentID": equipment_id,
            "customerName": customer_name,
            "customerPhone": customer_phone,
            "customerEmail": customer_email,
            "customerAddress": customer_address,
            "technicianName": technician_name,
            "technicianEmail": technician_email,
            "technicianPhone": technician_phone,
            "rating": rating,
            "openingDate": opening_date,
            "closingDate": closing_date,
            "problemDescription": problem_description,
            "issue": issue,
            "status": status,
            "equipmentType": equipment_type
        }
        #save_service_repair_to_file(service_repair_id, policy_number, service_id, equipment_id, customer_name, customer_phone, customer_email, customer_address, technician_name, technician_email, technician_phone, rating, opening_date, closing_date, problem_description, issue, status, equipment_type)
        print("Update the database")
        return {"status": "success", "message": "Service repair added"}
    except Exception as e:
        print(f"Error adding service repair data: {e}")
        return {"status": "error", "message": str(e)}

#Function used to update the status of the service repair in the file
def update_status(file_path,status,srid):
    updated_lines = []
    with open(file_path, 'r') as file:
        lines = file.readlines()
        for line in lines:
            data = json.loads(line)
            if data["service_repair_id"] == srid:
                data["status"] = status
            updated_lines.append(json.dumps(data))
    
    with open(file_path, 'w') as file:
        for line in updated_lines:
            file.write(line + '\n')

#Function used to update the issue of the service repair in the file
def update_issue(file_path,issue,srid):
    updated_lines = []
    with open(file_path, 'r') as file:
        lines = file.readlines()
        for line in lines:
            data = json.loads(line)
            if data["service_repair_id"] == srid:
                data["issue"] = issue
            updated_lines.append(json.dumps(data))
    
    with open(file_path, 'w') as file:
        for line in updated_lines:
            file.write(line + '\n')

#Function used to update the rating of the service repair in the file
def update_rating(file_path,rating,srid):
    updated_lines = []
    with open(file_path, 'r') as file:
        lines = file.readlines()
        for line in lines:
            data = json.loads(line)
            if data["service_repair_id"] == srid:
                data["rating"] = int(rating)
            updated_lines.append(json.dumps(data))
    
    with open(file_path, 'w') as file:
        for line in updated_lines:
            file.write(line + '\n')

#Function used to update the technicain details to the file
def update_technician(file_path,srid,name,email,phone,status):
    updated_lines = []
    with open(file_path, 'r') as file:
        lines = file.readlines()
        for line in lines:
            data = json.loads(line)
            if data["service_repair_id"] == srid:
                data["technicianName"] = name
                data["technicianEmail"] = email
                data["technicianPhone"]= phone
                data["status"]= status
            updated_lines.append(json.dumps(data))
    
    with open(file_path, 'w') as file:
        for line in updated_lines:
            file.write(line + '\n')

#funtion used to get all the list of pending service repair
def get_pending_service_repairs_data(service_repair_database):
    """Retrieve all service repairs with status 'pending'."""
    try:
        pending_repairs = {k: v for k, v in service_repair_database.items() if v["status"] == "pending"}
        #print(pending_repairs)
        return pending_repairs
    except Exception as e:
        print(f"Error retrieving pending service repairs: {e}")
        return {"status": "error", "message": str(e)}

#funtion used to get all the list of ongoing service repair
def get_ongoing_service_repairs_data(service_repair_database):
    """Retrieve all service repairs with status 'ongoing'."""
    try:
        ongoing_repairs = {k: v for k, v in service_repair_database.items() if v["status"] == "ongoing"}
        return ongoing_repairs
    except Exception as e:
        print(f"Error retrieving ongoing service repairs: {e}")
        return {"status": "error", "message": str(e)}

#funtion used to get all the list of completed service repair
def get_completed_service_repairs_data(service_repair_database):
    """Retrieve all service repairs with status 'completed'."""
    try:
        completed_repairs = {k: v for k, v in service_repair_database.items() if v["status"] == "completed"}
        return completed_repairs
    except Exception as e:
        print(f"Error retrieving completed service repairs: {e}")
        return {"status": "error", "message": str(e)}

#Function to store the service repais details to the blockchain
def addServiceRepair(policy_database,customer_database,stock_database,technician_database,service_repair_database,EqId,description,temp_service_repair_database):
    #Fetching Initial details
    serviceID=stock_database[EqId]["serviceID"]
    policyID=stock_database[EqId]["policyNumbers"][0]
    customerID=""
    customerIDs=list(customer_database.keys())
    for i in customerIDs:
        if serviceID in customer_database[i]["serviceIDs"]:
            customerID=i
    #Fetching customer details
    customer_name=customer_database[customerID]["name"]
    customer_phone=customer_database[customerID]["phone"]
    customer_email=customer_database[customerID]["email"]
    customer_address=customer_database[customerID]["address"]
    #Fetching technician details
    """technicianID="T3"
    technician_name=technician_database[technicianID]["technicianName"]
    technician_email=technician_database[technicianID]["technicianEmail"]
    technician_phone=technician_database[technicianID]["technicianPhone"]"""
    #Generate the service repair id
    serviceRepairID=f"SR{customerID}{random.randint(1000, 9999)}"
    EqType=stock_database[EqId]["type"]
    status="pending"
    rating=0
    issue="Not diagnosed"
    #calculating dates
    current_date = datetime.now().date()
    openingDate=current_date.strftime('%Y-%m-%d')
    new_date = current_date + timedelta(days=10)
    closingDate=new_date.strftime('%Y-%m-%d')
    #Preparing the object for the blockchain
    obj={"serviceID":serviceID,"policyID":policyID,"customer_name":customer_name,"customer_phone":customer_phone,"customer_email":customer_email,"customer_address":customer_address,
         "technician_name":"","technician_email":"","technician_phone":"","serviceRepairID":serviceRepairID,"EqType":EqType,"status":status,"rating":rating,
         "issue":issue,"openingDate":openingDate,"closingDate":closingDate,"EqId":EqId,"description":description,"previousHash":""}
    #adding to the block chain
    temp_service_repair_database[serviceRepairID]=cook_service_repair(obj)
    print("********************")
    print(temp_service_repair_database)
    print("********************")
    #Updating the service repair database
    add_service_repair_data(service_repair_database, serviceRepairID, policyID, serviceID, EqId, customer_name, customer_phone, customer_email, customer_address, "", "", "", rating, openingDate, closingDate, description, issue, status, EqType)
    #update the policy database
    update_policy_data(policy_database, policyID, serviceRepairID)
    #update stock database
    update_stock_repair_data(stock_database, EqId, serviceRepairID)
    
    return {"status": "success", "message": "Service repair added"}

#Function to change status 
def updateRepairStatus(service_repair_database,SRID,status,temp_service_repair_database):
    #Fetching the details from the block chain
    details=single_load(temp_service_repair_database[SRID])
    print("UpdateRepairStatsu:fetched details completed")
    #Preparing the object for the blockchain
    obj={"serviceID":details["serviceID"],"policyID":details["policyNumber"],"customer_name":details["customerName"],"customer_phone":details["customerPhone"],"customer_email":details["customerEmail"],"customer_address":details["customerAddress"],
         "technician_name":details["technicianName"],"technician_email":details["technicianEmail"],"technician_phone":details["technicianPhone"],"serviceRepairID":SRID,"EqType":details["equipmentType"],"status":status,
         "rating":details["rating"],"issue":details["issue"],"openingDate":details["openingDate"],"closingDate":details["closingDate"],"EqId":details["equipmentID"],"description":details["problemDescription"],"previousHash":temp_service_repair_database[SRID]}
    #adding to the block chain
    print("Constructing the block completed")
    temp_service_repair_database[SRID]=cook_service_repair(obj)
    print("********************")
    print(temp_service_repair_database)
    print("********************")
#function to update rating
def updateRepairRating(service_repair_database,SRID,rating,temp_service_repair_database):
    #Fetching the details from the block chain
    details=single_load(temp_service_repair_database[SRID])
    #Preparing the object for the blockchain
    print("UpdateRepairRating:fetched details completed")
    obj={"serviceID":details["serviceID"],"policyID":details["policyNumber"],"customer_name":details["customerName"],"customer_phone":details["customerPhone"],"customer_email":details["customerEmail"],"customer_address":details["customerAddress"],
         "technician_name":details["technicianName"],"technician_email":details["technicianEmail"],"technician_phone":details["technicianPhone"],"serviceRepairID":SRID,"EqType":details["equipmentType"],"status":details["status"],
         "rating":rating,"issue":details["issue"],"openingDate":details["openingDate"],"closingDate":details["closingDate"],"EqId":details["equipmentID"],"description":details["problemDescription"],"previousHash":temp_service_repair_database[SRID]}
    #adding to the block chain
    temp_service_repair_database[SRID]=cook_service_repair(obj)
    print("********************")
    print(temp_service_repair_database)
    print("********************")
    print("RATING ADDED")
    return {"status": "success", "message": "Rating added"}

#Function to update Technician details
def updateTechnician(technician_database,service_repair_database,repair_list,technicianID,temp_service_repair_database):
    for i in repair_list:
        status="ongoing"
        technician_name=technician_database[technicianID]["technicianName"]
        technician_email=technician_database[technicianID]["technicianEmail"]
        technician_phone=technician_database[technicianID]["technicianPhone"]
        service_repair_database[i]["technicianName"]=technician_name
        service_repair_database[i]["technicianEmail"]=technician_email
        service_repair_database[i]["technicianPhone"]=technician_phone
        service_repair_database[i]["status"]=status
        #Fetching the details from the block chain
        details=single_load(temp_service_repair_database[i])
        obj={"serviceID":details["serviceID"],"policyID":details["policyNumber"],"customer_name":details["customerName"],"customer_phone":details["customerPhone"],"customer_email":details["customerEmail"],"customer_address":details["customerAddress"],
         "technician_name":technician_name,"technician_email":technician_email,"technician_phone":technician_phone,"serviceRepairID":i,"EqType":details["equipmentType"],"status":status,
         "rating":details["rating"],"issue":details["issue"],"openingDate":details["openingDate"],"closingDate":details["closingDate"],"EqId":details["equipmentID"],"description":details["problemDescription"],"previousHash":temp_service_repair_database[i]}
        #adding to the block chain
        print("Constructing the block completed")
        temp_service_repair_database[i]=cook_service_repair(obj)
        #update_technician(SERVICE_REPAIR_FILE,i,technician_name,technician_email,technician_phone,"ongoing")
    return {"status": "success", "message": "Technician assigned"}

#Function to close the serviceRepair
def closeServiceRepair(service_repair_database,stock_database,SRID,issue,temp_service_repair_database):
    #Fetching the details from the block chain
    details={}
    while(1):
        details=single_load(temp_service_repair_database[SRID])
        if "serviceID" in details:
            print("It is present in the details")
            break
        time.sleep(1)
    print("closeServiceRepair:fetched details completed")
    #Preparing the object for the blockchain
    obj={"serviceID":details["serviceID"],"policyID":details["policyNumber"],"customer_name":details["customerName"],"customer_phone":details["customerPhone"],"customer_email":details["customerEmail"],"customer_address":details["customerAddress"],
         "technician_name":details["technicianName"],"technician_email":details["technicianEmail"],"technician_phone":details["technicianPhone"],"serviceRepairID":SRID,"EqType":details["equipmentType"],"status":"completed",
         "rating":details["rating"],"issue":issue,"openingDate":details["openingDate"],"closingDate":details["closingDate"],"EqId":details["equipmentID"],"description":details["problemDescription"],"previousHash":temp_service_repair_database[SRID]}
    #adding to the block chain
    temp_service_repair_database[SRID]=cook_service_repair(obj)
    print("********************")
    print(temp_service_repair_database)
    print("********************")
    update_stock(stock_database,details["equipmentID"],"customer",details["serviceID"])
    return {"status": "success", "message": "Service repair closed"}


