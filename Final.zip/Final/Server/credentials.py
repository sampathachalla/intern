import json

# Load credentials from file
def load_credentials(file_path):
    credentials = []
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line:  # Skip empty lines
                try:
                    credentials.append(json.loads(line))
                except json.JSONDecodeError:
                    print(f"Error decoding JSON: {line}")
    return credentials

# Function to add new credential and save it to the dictionary
def add_credential(credentials_database, usertype, username, password):
    # Generate a new ID based on user type
    prefix = {
        'user': 'U',
        'agent': 'A',
        'technician': 'T'
    }[usertype]
    
    # Find the maximum current id for the given usertype and increment it by 1 for the new id
    current_ids = [int(cred['id'][1:]) for cred in credentials_database.values() if cred['usertype'] == usertype]
    max_id = max(current_ids, default=0)
    new_id = f"{prefix}{max_id + 1}"

    new_credential = {
        "id": new_id,
        "usertype": usertype,
        "username": username,
        "password": password
    }

    # Add the new credential
    credentials_database[username] = new_credential

    # Save all credentials back to the file
    save_credentials_to_file(credentials_database, 'credentials_data.txt')

# Function to save credentials to file
def save_credentials_to_file(credentials_database, file_path):
    with open(file_path, 'w') as file:
        for credential in credentials_database.values():
            file.write(json.dumps(credential) + "\n")

# Function to verify credentials
def verify_credential(credentials_database, username, password, usertype):
    if username in credentials_database and credentials_database[username]["password"] == password and credentials_database[username]["usertype"] == usertype:
        return True
    return False

# Example usage
if __name__ == "__main__":
    # Load credentials from file
    file_path = 'credentials_data.txt'
    credentials = load_credentials(file_path)
    
    # Convert list to dictionary for in-memory database
    credentials_dict = {cred['username']: cred for cred in credentials}
    
    # Add a new credential
    add_credential(credentials_dict, 'user', 'user4', 'NewPass123!')
    
    # Verify a credential
    is_verified = verify_credential(credentials_dict, 'user4', 'NewPass123!', 'user')
    print(f"Credential verified: {is_verified}")
    
    # Save credentials back to file
    save_credentials_to_file(credentials_dict, file_path)
