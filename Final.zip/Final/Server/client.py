import zmq
import json

def send_request(action, data):
    context = zmq.Context()
    socket = context.socket(zmq.REQ)
    socket.connect("tcp://localhost:5560")

    request = {
        "action": action,
        "id": data  # Ensure the key matches what the backend expects
    }

    try:
        socket.send(json.dumps(request).encode('utf-8'))
        response = socket.recv()
        print("Received reply:", json.loads(response.decode('utf-8')))
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        socket.close()
        context.term()

if __name__ == "__main__":
    customer_id = "U1"  # Change this to the customer ID you want to test
    send_request("fetch_customer_details", customer_id)
