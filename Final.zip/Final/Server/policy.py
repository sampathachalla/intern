import json
import os
import time

POLICY_FILE = "policy_data.txt"

#Function used to load the policy data from the file to the dictionary database
def load_policies_from_file():
    """Load policy data from a text file into a dictionary."""
    policy_database = {}
    try:
        if os.path.exists(POLICY_FILE):
            with open(POLICY_FILE, 'r') as file:
                for line in file:
                    policy = json.loads(line.strip())
                    policy_database[policy["policyNumber"]] = {
                        "equipmentID": policy["equipmentID"],
                        "service_repair_IDs": policy["service_repair_IDs"]
                    }
    except Exception as e:
        print(f"Error loading policies from file: {e}")
    return policy_database

#Function used to save the new policy data to the file
def save_policy_to_file(policy_number, equipment_id, service_repair_ids):
    """Save a new policy to the text file."""
    try:
        with open(POLICY_FILE, 'a') as file:
            policy = {
                "policyNumber": policy_number,
                "equipmentID": equipment_id,
                "service_repair_IDs": service_repair_ids
            }
            file.write(json.dumps(policy) + "\n")
    except Exception as e:
        print(f"Error saving policy to file: {e}")

#function used to delete the policy details from the file
def delete_policy(policy_number):
    """Delete a policy from the text file."""
    try:
        # Read the existing policies
        with open(POLICY_FILE, 'r') as file:
            policies = file.readlines()

        updated_policies = []
        policy_found = False

        for policy in policies:
            policy_data = json.loads(policy.strip())
            if policy_data["policyNumber"] == policy_number:
                # Mark the policy as found and skip adding it to the updated list
                policy_found = True
                #print(f"Deleted policy: {policy_data}")
            else:
                updated_policies.append(json.dumps(policy_data))

        if not policy_found:
            print(f"Policy number {policy_number} not found.")
            return

        # Write the updated policies back to the file
        with open(POLICY_FILE, 'w') as file:
            for updated_policy in updated_policies:
                file.write(updated_policy + "\n")

        print(f"Policy number {policy_number} deleted successfully.")

    except Exception as e:
        print(f"Error deleting policy: {e}")

#function which return all the policy details in the list
def get_all_policies(policy_database):
    """Retrieve all policy data from the policy database."""
    try:
        return dict(policy_database)  # Convert managed dict to regular dict for serialization
    except Exception as e:
        print(f"Error retrieving all policies: {e}")
        return {"status": "error", "message": str(e)}

#Function used to add the policy data to the local database dictionary
def add_policy_data(policy_database, policy_number, equipment_id, service_repair_ids):
    """Add policy data to the policy database and save to file."""
    try:
        if policy_number in policy_database:
            return {"status": "error", "message": "Policy number already exists"}
        policy_database[policy_number] = {"equipmentID": equipment_id, "service_repair_IDs": service_repair_ids}
        save_policy_to_file(policy_number, equipment_id, service_repair_ids)
        return {"status": "success", "message": "Policy added"}
    except Exception as e:
        print(f"Error adding policy data: {e}")
        return {"status": "error", "message": str(e)}

#Function used to update the policy data in the local dictionary database
def update_policy_data(policy_database, policyID, serviceRepairID):
    service_repair_IDs = policy_database[policyID]["service_repair_IDs"]
    equipmentID = policy_database[policyID]["equipmentID"]
    service_repair_IDs.append(serviceRepairID)
    policy_database[policyID]["service_repair_IDs"] = service_repair_IDs
    #delete_policy(policyID)
    time.sleep(1)
    #save_policy_to_file(policyID, equipmentID, service_repair_IDs)
