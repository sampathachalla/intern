import json
import os
from collections import Counter

STOCK_FILE = "stock_data.txt"

#Function used to load the stock data from the file to the dictionary database
def load_stock_from_file():
    """Load stock data from a text file into a dictionary."""
    stock_database = {}
    try:
        if os.path.exists(STOCK_FILE):
            with open(STOCK_FILE, 'r') as file:
                for line in file:
                    stock = json.loads(line.strip())
                    stock_database[stock["equipmentID"]] = {
                        "type": stock["type"],
                        "status": stock["status"],
                        "serviceID": stock["serviceID"],
                        "policyNumbers": stock["policyNumbers"],
                        "service_repair_IDs": stock["service_repair_IDs"]
                    }
    except Exception as e:
        print(f"Error loading stock from file: {e}")
    return stock_database

#function used to save the stock data to the file
def save_stock_to_file(equipment_id, equipment_type, status, service_id, policy_numbers, service_repair_ids):
    """Save a new stock entry to the text file."""
    try:
        with open(STOCK_FILE, 'a') as file:
            stock = {
                "equipmentID": equipment_id,
                "type": equipment_type,
                "status": status,
                "serviceID": service_id,
                "policyNumbers": policy_numbers,
                "service_repair_IDs": service_repair_ids
            }
            file.write(json.dumps(stock) + "\n")
        return {"status": "success", "message": "Stock saved"}
    except Exception as e:
        print(f"Error saving stock to file: {e}")
        return {"status": "error", "message": str(e)}

#Fucntion used to get the list of all the equipments stock details
def get_all_stock(stock_database):
    """Retrieve all stock data from the stock database."""
    try:
        return dict(stock_database)  # Convert managed dict to regular dict for serialization
    except Exception as e:
        print(f"Error retrieving all stock: {e}")
        return {"status": "error", "message": str(e)}

#function used to add the stock data to the local database dictionary
def add_stock_data(stock_database, equipment_id, equipment_type, status, service_id, policy_numbers, service_repair_ids):
    """Add stock data to the stock database and save to file."""
    try:
        if equipment_id in stock_database:
            return {"status": "error", "message": "Equipment ID already exists"}
        stock_database[equipment_id] = {
            "type": equipment_type,
            "status": status,
            "serviceID": service_id,
            "policyNumbers": policy_numbers,
            "service_repair_IDs": service_repair_ids
        }
        save_stock_to_file(equipment_id, equipment_type, status, service_id, policy_numbers, service_repair_ids)
        return {"status": "success", "message": "Stock added"}
    except Exception as e:
        print(f"Error adding stock data: {e}")
        return {"status": "error", "message": str(e)}

#Function used to delete the stock details from the file
def delete_stock_entry(equipment_id):
    """Delete a stock entry from the text file based on equipment ID."""
    try:
        # Read the existing stock entries
        with open(STOCK_FILE, 'r') as file:
            stocks = file.readlines()

        updated_stocks = []
        entry_found = False

        for stock in stocks:
            stock_data = json.loads(stock.strip())
            if stock_data["equipmentID"] == equipment_id:
                # Mark the entry as found and skip adding it to the updated list
                entry_found = True
                #print(f"Deleted stock entry: {stock_data}")
            else:
                updated_stocks.append(json.dumps(stock_data))

        if not entry_found:
            print(f"Equipment ID {equipment_id} not found.")
            return {"status": "error", "message": "Equipment ID not found"}

        # Write the updated stock entries back to the file
        with open(STOCK_FILE, 'w') as file:
            for updated_stock in updated_stocks:
                file.write(updated_stock + "\n")

        print(f"Equipment ID {equipment_id} deleted successfully.")
        return {"status": "success", "message": "Stock entry deleted"}

    except Exception as e:
        print(f"Error deleting stock entry: {e}")
        return {"status": "error", "message": str(e)}
    
# Function to count total equipment and their statuses
def count_total_equipment(stock_database):
    try:
        total_equipment = len(stock_database)
        status_counts = {
            'warehouse': 0,
            'customer': 0,
            'repair': 0,
            'discarded': 0
        }

        for equipment in stock_database.values():
            status = equipment.get('status', '')
            if status in status_counts:
                status_counts[status] += 1

        result = {
            'total_equipment': total_equipment,
            'status_counts': status_counts
        }

        return result

    except Exception as e:
        print(f"Error in count_total_equipment: {e}")
        return None

# Function to count equipment based on type and status
def count_equipment_by_type(stock_database):
    try:
        type_status_counts = {}

        for equipment in stock_database.values():
            equipment_type = equipment.get('type', '')
            status = equipment.get('status', '')

            if equipment_type not in type_status_counts:
                type_status_counts[equipment_type] = {
                    'warehouse': 0,
                    'customer': 0,
                    'repair': 0,
                    'discarded': 0
                }

            if status in type_status_counts[equipment_type]:
                type_status_counts[equipment_type][status] += 1

        return type_status_counts

    except Exception as e:
        print(f"Error in count_equipment_by_type: {e}")
        return None


#Function used to fetch the details of the individual equipment details
def fetch_equipment_details(equipment_id, stock_database, service_repair_database, customer_database):
    if equipment_id not in stock_database:
        return {"status": "error", "message": "Equipment ID not found"}

    equipment = stock_database[equipment_id]
    service_id = equipment['serviceID']

    # Fetch current location (customer address)
    current_location = None
    for customer_id, customer in customer_database.items():
        if service_id in customer['serviceIDs']:
            current_location = customer['address']
            break

    # Count service repairs
    service_repair_ids = equipment.get('service_repair_IDs', [])
    repair_count = len(service_repair_ids)

    # Fetch issues and determine the major issue
    issues = []
    for repair_id in service_repair_ids:
        if repair_id in service_repair_database:
            issues.append(service_repair_database[repair_id]['issue'])

    major_issue = None
    if issues:
        issue_counts = Counter(issues)
        major_issue = issue_counts.most_common(1)[0][0]

    return {
        'type': equipment['type'],
        'currentLocation': current_location,
        'repairCount': repair_count,
        'majorIssue': major_issue
    }

#Function used to update the stock
def update_stock_repair_data(stock_database, EqId, srID):
    equipment_id = EqId
    equipment_type = stock_database[EqId]["type"]
    status = "repair"
    service_id = stock_database[EqId]["serviceID"]
    policy_numbers = stock_database[EqId]["policyNumbers"]
    service_repair_ids = stock_database[EqId]["service_repair_IDs"]
    
    
    stock_database[EqId]["service_repair_IDs"].append(srID)
    

#Function used to update the status of the stock in the local database dictionary
def update_stock_status(stock_database,EqId,status):
    equipment_id = EqId
    equipment_type = stock_database[EqId]["type"]
    service_id = stock_database[EqId]["serviceID"]
    policy_numbers = stock_database[EqId]["policyNumbers"]    
    # Remove the existing entry from the file
    delete_stock_entry(equipment_id)
    save_stock_to_file(equipment_id, equipment_type, status, service_id, policy_numbers,[])

#Function used to update the stock
def update_stock(stock_database,EqId,status,service_id):
    equipment_id = EqId
    equipment_type = stock_database[EqId]["type"]
    policy_numbers = stock_database[EqId]["policyNumbers"]
    # Remove the existing entry from the file
    delete_stock_entry(equipment_id)
    save_stock_to_file(equipment_id, equipment_type, status, str(service_id), policy_numbers,[])

    
    

