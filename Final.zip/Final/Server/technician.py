import json
import os
from datetime import datetime, timedelta
from datetime import datetime
from service_repair import updateRepairStatus
from layered import cook_service_repair,multi_load_order

ORDER_PARTS_FILE = "order_parts_data.txt"
TECHNICIAN_FILE = "technician_data.txt"

#Function used to load the technician details from the file to the dictionary database
def load_order_parts_from_file():
    """Load order parts data from a text file into a dictionary."""
    order_parts_database = {}
    try:
        if os.path.exists(ORDER_PARTS_FILE):
            with open(ORDER_PARTS_FILE, 'r') as file:
                for line in file:
                    order = json.loads(line.strip())
                    order_parts_database[order["order_id"]] = order
    except Exception as e:
        print(f"Error loading order parts from file: {e}")
    return order_parts_database

#Function used to save the order parts data to the file
def save_order_part_to_file(order):
    """Save a new order part to the text file."""
    try:
        with open(ORDER_PARTS_FILE, 'a') as file:
            file.write(json.dumps(order) + "\n")
    except Exception as e:
        print(f"Error saving order part to file: {e}")

#Function used to store the parts order data to the local database dictionary
def store_order_parts(order_parts_database,data,temp_order_parts_database):
    """Store order parts data in the order parts database and save to file."""
    try:
        order_id = f"order_{len(temp_order_parts_database) + 1}"
        order = {
            "order_id": order_id,
            "technicianId": data["username"],
            "serviceRepairId": data["serviceRepairId"],
            "equipmentType": data["equipmentType"],
            "partsList": data["partsList"],
            "orderedDate": datetime.now().strftime("%Y-%m-%d"),
            "status": "ordered",
            "deliveryDate": (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
        }
        temp_order_parts_database[order_id]=cook_service_repair(order)
        #order_parts_database[order_id] = order
        save_order_part_to_file(order)
        return {"status": "success"}
    except Exception as e:
        print(f"Error storing order parts: {e}")
        return {"status": "error", "message": str(e)}

#Function used to get the list of order parts from the local database dictionary
def get_all_order_parts(order_parts_database):
    """Retrieve all order parts data."""
    try:
        order_parts_dict=multi_load_order(order_parts_database)
        return list(order_parts_dict.values())
    except Exception as e:
        print(f"Error retrieving order parts: {e}")
        return {"status": "error", "message": str(e)}

#function used to load the technician data from the file to the local database dictionary
def load_technicians_from_file():
    """Load technician data from a text file into a dictionary."""
    technician_database = {}
    try:
        if os.path.exists(TECHNICIAN_FILE):
            with open(TECHNICIAN_FILE, 'r') as file:
                for line in file:
                    technician = json.loads(line.strip())
                    technician_database[technician["techId"]] = technician
    except Exception as e:
        print(f"Error loading technicians from file: {e}")
    return technician_database

#function used to store the new technician details in the file
def save_technician_to_file(technician):
    """Save a new technician to the text file."""
    try:
        with open(TECHNICIAN_FILE, 'a') as file:
            file.write(json.dumps(technician) + "\n")
    except Exception as e:
        print(f"Error saving technician to file: {e}")

#Fucntion used to add the new technician to the database dictionary
def add_technician(technician_database, data):
    """Add technician data to the technician database and save to file."""
    try:
        tech_id = f"T{len(technician_database) + 1}"
        technician = {
            "techId": tech_id,
            "technicianName": data["technicianName"],
            "technicianEmail": data["technicianEmail"],
            "technicianPhone": data["technicianPhone"]
        }
        technician_database[tech_id] = technician
        save_technician_to_file(technician)
        return {"status": "success"}
    except Exception as e:
        print(f"Error adding technician: {e}")
        return {"status": "error", "message": str(e)}

#Function used to get the list of all technicians
def get_all_technicians(technician_database):
    """Retrieve all technician data."""
    try:
        return list(technician_database.values())
    except Exception as e:
        print(f"Error retrieving technicians: {e}")
        return {"status": "error", "message": str(e)}

#function used to get the ID of all the technician
def get_all_technicians_ID(technician_database):
    """Retrieve all technician data."""
    try:
        return list(technician_database.keys())
    except Exception as e:
        print(f"Error retrieving technicians: {e}")
        return {"status": "error", "message": str(e)}



from datetime import datetime

#Fucntion used to calculate all the performance of the technician and send to the frontend upon the request
def calculate_technician_performance(technician_id, service_repair_database, technician_database, order_parts_database):
    if technician_id not in technician_database:
        return {"status": "error", "message": "Technician ID not found"}

    technician_name = technician_database[technician_id]['technicianName']
    
    completed_repairs = []
    total_rating = 0
    total_service_time = 0

    for repair_id, repair in service_repair_database.items():
        if repair['technicianName'] == technician_name and repair['status'] == 'completed':
            completed_repairs.append(repair)
            total_rating += repair['rating']
            
            opening_date = datetime.strptime(repair['openingDate'], '%Y-%m-%d')
            closing_date = datetime.strptime(repair['closingDate'], '%Y-%m-%d')
            service_time = (closing_date - opening_date).days
            total_service_time += service_time

    if not completed_repairs:
        return {"status": "error", "message": "No completed repairs found for this technician"}

    average_rating = total_rating / len(completed_repairs)
    average_service_time = total_service_time / len(completed_repairs)

    return {
        'technicianName': technician_name,
        'averageRating': average_rating,
        'averageServiceTime': average_service_time
    }
