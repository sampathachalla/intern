// src/App.jsx
import React, { useState } from "react";
import CompanyInfo from "./components/loginComponents/CompanyInfo";
import Login from "./components/loginComponents/Login";
import Signup from "./components/loginComponents/Signup";
import UserDashboard from "./components/userComponents/UserDashboard";
import AgentDashboard from "./components/agentComponents/AgentDashboard";
import TechnicianDashboard from "./components/technicianComponents/TechnicianDashboard";
import styles from "./app.module.css";

function App() {
  const [showLogin, setShowLogin] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [username, setUsername] = useState("");

  const switchToSignup = () => {
    setShowLogin(false);
  };

  const switchToLogin = () => {
    setShowLogin(true);
  };

  const handleLoginSuccess = (userType, username) => {
    setCurrentUser(userType);
    setUsername(username);
  };

  return (
    <div className={styles.container}>
      {!currentUser && <CompanyInfo />}
      {currentUser ? (
        currentUser === "user" ? (
          <UserDashboard username={username} />
        ) : currentUser === "agent" ? (
          <AgentDashboard username={username} />
        ) : (
          <TechnicianDashboard username={username} />
        )
      ) : showLogin ? (
        <Login
          switchToSignup={switchToSignup}
          onLoginSuccess={handleLoginSuccess}
        />
      ) : (
        <Signup switchToLogin={switchToLogin} />
      )}
    </div>
  );
}

export default App;
