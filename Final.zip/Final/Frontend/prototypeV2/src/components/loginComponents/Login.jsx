import React, { useState, useEffect } from "react";
import styles from "./login.module.css";

const Login = ({ switchToSignup, onLoginSuccess }) => {
  const [userType, setUserType] = useState("user");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    try {
      const response = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userType, username, password }),
      });
      const data = await response.json();
      if (data.success) {
        onLoginSuccess(userType, username);
      } else {
        alert(`Login failed: ${data.message}`);
      }
    } catch (error) {
      console.error("Error during login:", error);
      alert("Login failed: Network error");
    }
  };

  useEffect(() => {
    const loginForm = document.querySelector(`.${styles.loginForm}`);
    loginForm.classList.add(styles.slideIn);
  }, [userType]);

  const userTypeLabel =
    userType.charAt(0).toUpperCase() + userType.slice(1) + " Login";

  return (
    <div className={styles.loginContainer}>
      <div className={styles.loginForm}>
        <h2>{userTypeLabel}</h2>
        <div>
          <select
            value={userType}
            onChange={(e) => setUserType(e.target.value)}
            className={styles.select}
          >
            <option value="user">User</option>
            <option value="agent">Agent</option>
            <option value="technician">Technician</option>
          </select>
        </div>
        <div>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className={styles.input}
          />
        </div>
        <div>
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={styles.input}
          />
        </div>
        <div className={styles.buttonContainer}>
          <button onClick={handleLogin} className={styles.button}>
            Login
          </button>
          <button onClick={switchToSignup} className={styles.button}>
            Signup
          </button>
        </div>
      </div>
    </div>
  );
};

export default Login;
