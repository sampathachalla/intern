// src/components/Signup.js
import React, { useState, useEffect } from "react";
import styles from "./signup.module.css";

const Signup = ({ switchToLogin }) => {
  const [userType, setUserType] = useState("user");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleSignup = async () => {
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }

    try {
      const response = await fetch("http://localhost:5000/api/auth/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userType, username, password }),
      });

      const data = await response.json();
      if (data.success) {
        alert("Signup successful!");
        switchToLogin();
      } else {
        alert(`Signup failed: ${data.message}`);
      }
    } catch (error) {
      console.error("Error during signup:", error);
      alert("Signup failed: Network error");
    }
  };

  useEffect(() => {
    const signupForm = document.querySelector(`.${styles.signupForm}`);
    signupForm.classList.add(styles.slideIn);
  }, [userType]);

  const userTypeLabel =
    "Sign Up as " + userType.charAt(0).toUpperCase() + userType.slice(1);

  return (
    <div className={styles.signupContainer}>
      <div className={styles.signupForm}>
        <h2>{userTypeLabel}</h2>
        <div>
          <select
            value={userType}
            onChange={(e) => setUserType(e.target.value)}
            className={styles.select}
          >
            <option value="user">User</option>
            <option value="agent">Agent</option>
            <option value="technician">Technician</option>
          </select>
        </div>
        <div>
          <input
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className={styles.input}
          />
        </div>
        <div>
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={styles.input}
          />
        </div>
        <div>
          <input
            type="password"
            placeholder="Confirm Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className={styles.input}
          />
        </div>
        <div className={styles.buttonContainer}>
          <button onClick={handleSignup} className={styles.button}>
            Signup
          </button>
          <button onClick={switchToLogin} className={styles.button}>
            Login
          </button>
        </div>
      </div>
    </div>
  );
};

export default Signup;
