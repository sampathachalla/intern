import React from "react";
import styles from "./UserConsole.module.css";

const UserConsole = ({ equipmentDetails, nameToIdMapping }) => {
  return (
    <div className={styles.container}>
      <h2 className={styles.heading}>Customer Console</h2>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Equipment ID</th>
            <th>Type</th>
          </tr>
        </thead>
        <tbody>
          {equipmentDetails.map((equipment) => (
            <tr key={equipment.equipment_id}>
              <td>{equipment.equipment_id}</td>
              <td>{equipment.type}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UserConsole;
