// src/components/userComponents/UserDashboard.jsx
import React, { useState } from "react";
import Header from "./Header";
import Selection from "./Selection";
import ContentArea from "./ContentArea";
import Footer from "./Footer";
import styles from "./UserDashboard.module.css";

const UserDashboard = ({ username }) => {
  const [selectedSection, setSelectedSection] = useState("");

  return (
    <div className={styles.dashboard}>
      <Header />
      <Selection onSelectSection={setSelectedSection} />
      <ContentArea section={selectedSection} username={username} />
      <Footer />
    </div>
  );
};

export default UserDashboard;
