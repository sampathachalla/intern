import React, { useState } from "react";
import Header from "./Header";
import Selection from "./Selection";
import ContentArea from "./ContentArea";
import Footer from "./Footer";
import styles from "./UserDashboard.module.css";

const UserDashboard = ({ username }) => {
  const [selectedSection, setSelectedSection] = useState("console");

  return (
    <div className={styles.dashboard}>
      <Header username={username} />
      <div className={styles.mainContent}>
        <Selection
          onSelectSection={setSelectedSection}
          selectedSection={selectedSection}
        />
        <ContentArea section={selectedSection} username={username} />
      </div>
      <Footer />
    </div>
  );
};

export default UserDashboard;
