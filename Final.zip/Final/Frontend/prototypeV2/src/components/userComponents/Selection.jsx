// src/components/agentComponents/Selection.jsx
import React, { useState } from "react";
import styles from "./Selection.module.css";

const Selection = ({ onSelectSection, selectedSection }) => {
  const handleButtonClick = (section) => {
    onSelectSection(section);
  };

  return (
    <div className={styles.selection}>
      <button
        className={selectedSection === "console" ? styles.selected : ""}
        onClick={() => handleButtonClick("console")}
      >
        Console
      </button>
      <button
        className={selectedSection === "service" ? styles.selected : ""}
        onClick={() => handleButtonClick("service")}
      >
        Service
      </button>
      <button
        className={selectedSection === "repairs" ? styles.selected : ""}
        onClick={() => handleButtonClick("repairs")}
      >
        Repairs
      </button>
    </div>
  );
};

export default Selection;
