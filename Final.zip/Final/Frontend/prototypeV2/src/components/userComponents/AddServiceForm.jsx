import React, { useState } from "react";
import axios from "axios";
import styles from "./AddServiceForm.module.css";

const AddServiceForm = ({ nameToIdMapping, username }) => {
  const [serviceType, setServiceType] = useState("individual");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [showMessageBox, setShowMessageBox] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await axios.post(
        "http://localhost:5000/api/user/add_service",
        {
          username,
          service_type: serviceType,
          email,
          phone,
          address,
        }
      );
      console.log("Service added successfully:", response.data);
      setSuccessMessage(
        "Service added successfully! It will take a few minutes to reflect the changes."
      );
      setShowMessageBox(true);
      setServiceType("individual");
      setEmail("");
      setPhone("");
      setAddress("");
    } catch (err) {
      console.error("Error adding service:", err);
    }

    setLoading(false);
  };

  const handleCloseMessageBox = () => {
    setShowMessageBox(false);
  };

  return (
    <div className={styles.container}>
      <h2 className={styles.heading}>Add Service</h2>
      <form onSubmit={handleSubmit} className={styles.form}>
        <div className={styles.formRow}>
          <div className={styles.formGroup}>
            <label htmlFor="username" className={styles.label}>
              Name:
            </label>
            <input
              type="text"
              id="username"
              value={username}
              readOnly
              className={styles.input}
            />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="serviceType" className={styles.label}>
              Service Type:
            </label>
            <select
              id="serviceType"
              value={serviceType}
              onChange={(e) => setServiceType(e.target.value)}
              className={styles.input}
            >
              <option value="individual">Individual</option>
              <option value="office">Office</option>
              <option value="mini-hub">Mini-Hub</option>
            </select>
          </div>
        </div>
        <div className={styles.formRow}>
          <div className={styles.formGroup}>
            <label htmlFor="email" className={styles.label}>
              Email:
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={styles.input}
            />
          </div>
          <div className={styles.formGroup}>
            <label htmlFor="phone" className={styles.label}>
              Phone:
            </label>
            <input
              type="text"
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className={styles.input}
            />
          </div>
        </div>
        <div className={styles.formGroup}>
          <label htmlFor="address" className={styles.label}>
            Address:
          </label>
          <input
            type="text"
            id="address"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            className={styles.input}
          />
        </div>
        <button type="submit" className={styles.submitButton}>
          Submit
        </button>
      </form>
      {loading && <div className={styles.loadingMessage}>Submitting...</div>}
      {showMessageBox && (
        <div className={styles.messageBox}>
          <div className={styles.messageContent}>
            <p>{successMessage}</p>
            <button
              onClick={handleCloseMessageBox}
              className={styles.closeButton}
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default AddServiceForm;
