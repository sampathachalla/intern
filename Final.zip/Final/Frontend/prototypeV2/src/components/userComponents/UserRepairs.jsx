import React, { useState } from "react";
import axios from "axios";
import styles from "./UserRepairs.module.css";

const UserRepairs = ({ repairDetails, nameToIdMapping }) => {
  const [filterStatus, setFilterStatus] = useState("all");
  const [showRatingForm, setShowRatingForm] = useState(false);
  const [currentRepairId, setCurrentRepairId] = useState(null);
  const [rating, setRating] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleFilterChange = (status) => {
    setFilterStatus(status);
  };

  const handleRatingButtonClick = (repairId) => {
    setCurrentRepairId(repairId);
    setShowRatingForm(true);
  };

  const handleRatingSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(
        "http://localhost:5000/api/user/update_rating",
        {
          action: "add_rating",
          service_repair_id: currentRepairId,
          rating: rating,
        }
      );
      console.log("Rating updated successfully:", response.data);
      setSuccessMessage("Rating added successfully.");
      setShowRatingForm(false);
      setRating("");
    } catch (err) {
      console.error("Error updating rating:", err);
    }
  };

  const handleSuccessMessageClose = () => {
    setSuccessMessage("");
  };

  const filteredRepairs = repairDetails.filter((repair) => {
    if (filterStatus === "all") return true;
    return repair.status === filterStatus;
  });

  return (
    <div className={styles.container}>
      <h2 className={styles.heading}>Repair Details</h2>
      <div className={styles.buttonContainer}>
        <button
          className={`${styles.button} ${
            filterStatus === "ongoing" ? styles.active : ""
          }`}
          onClick={() => handleFilterChange("ongoing")}
        >
          Ongoing
        </button>
        <button
          className={`${styles.button} ${
            filterStatus === "pending" ? styles.active : ""
          }`}
          onClick={() => handleFilterChange("pending")}
        >
          Pending
        </button>
        <button
          className={`${styles.button} ${
            filterStatus === "completed" ? styles.active : ""
          }`}
          onClick={() => handleFilterChange("completed")}
        >
          Completed
        </button>
        <button
          className={`${styles.button} ${
            filterStatus === "all" ? styles.active : ""
          }`}
          onClick={() => handleFilterChange("all")}
        >
          All
        </button>
      </div>
      <div className={styles.tableContainer}>
        <table className={styles.repairTable}>
          <thead>
            <tr>
              <th>Service Repair ID</th>
              <th>Equipment Type</th>
              <th>Default Name</th>
              <th>Equipment ID</th>
              <th>Technician Name</th>
              <th>Technician Phone</th>
              <th>Technician Email</th>
              <th>Rating</th>
              <th>Opening Date</th>
              <th>Closing Date</th>
              <th>Problem Description</th>
              <th>Status</th>
              <th>Add Rating</th>
            </tr>
          </thead>
          <tbody>
            {filteredRepairs.map((repair) => (
              <tr key={repair.service_repair_id}>
                <td>{repair.service_repair_id}</td>
                <td>{repair.equipment_type}</td>
                <td>{nameToIdMapping[repair.equipment_id] || "N/A"}</td>
                <td>{repair.equipment_id}</td>
                <td>{repair.technician_name}</td>
                <td>{repair.technician_phone}</td>
                <td>{repair.technician_email}</td>
                <td>{repair.rating}</td>
                <td>{repair.opening_date}</td>
                <td>{repair.closing_date}</td>
                <td>{repair.problem_description}</td>
                <td>{repair.status}</td>
                <td>
                  {repair.status === "completed" && (
                    <button
                      className={styles.ratingButton}
                      onClick={() =>
                        handleRatingButtonClick(repair.service_repair_id)
                      }
                    >
                      Add Rating
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showRatingForm && (
        <div className={styles.ratingFormContainer}>
          <form onSubmit={handleRatingSubmit} className={styles.ratingForm}>
            <h3>Add Rating</h3>
            <label>
              Rating:
              <input
                type="number"
                value={rating}
                onChange={(e) => setRating(e.target.value)}
                min="1"
                max="5"
                required
              />
            </label>
            <button type="submit" className={styles.submitButton}>
              Submit
            </button>
            <button
              type="button"
              className={styles.cancelButton}
              onClick={() => setShowRatingForm(false)}
            >
              Cancel
            </button>
          </form>
        </div>
      )}
      {successMessage && (
        <div className={styles.successMessage}>
          {successMessage}
          <button
            onClick={handleSuccessMessageClose}
            className={styles.closeButton}
          >
            X
          </button>
        </div>
      )}
    </div>
  );
};

export default UserRepairs;
