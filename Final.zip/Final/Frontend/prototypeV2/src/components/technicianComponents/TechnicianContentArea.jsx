import React, { useState, useEffect } from "react";
import axios from "axios";
import styles from "./TechnicianContentArea.module.css";
import TechnicianPendingRepairs from "./TechnicianPendingRepairs";
import TechnicianOngoingRepairs from "./TechnicianOngoingRepairs";
import TechnicianCompletedRepairs from "./TechnicianCompletedRepairs";
import OrderPartsForm from "./OrderPartsForm";
import OrderPartsTable from "./OrderPartsTable";

const TechnicianContentArea = ({ section, username }) => {
  const [pendingRepairIds, setPendingRepairIds] = useState([]);

  useEffect(() => {
    if (section === "orderParts") {
      axios
        .get("http://localhost:5000/api/technician/ongoing", {
          params: { username },
        })
        .then((response) => {
          const ids = response.data.map((repair) => repair.service_repair_id);
          setPendingRepairIds(ids);
        })
        .catch((error) => {
          console.error("Error fetching pending repair IDs:", error);
        });
    }
  }, [section, username]);

  let content;
  switch (section) {
    case "pending":
      content = <TechnicianPendingRepairs username={username} />;
      break;
    case "ongoing":
      content = <TechnicianOngoingRepairs username={username} />;
      break;
    case "completed":
      content = <TechnicianCompletedRepairs username={username} />;
      break;
    case "orderParts":
      content = (
        <OrderPartsForm
          pendingRepairIds={pendingRepairIds}
          username={username}
        />
      );
      break;
    case "orderStatus":
      content = <div>Order Status</div>;
      return (
        <div>
          <OrderPartsTable />
        </div>
      );
      break;
    default:
      content = <div>Welcome to the Technician Dashboard</div>;
  }

  return <main className={styles.contentArea}>{content}</main>;
};

export default TechnicianContentArea;
