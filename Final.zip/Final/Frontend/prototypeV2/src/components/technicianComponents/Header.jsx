import React from "react";
import styles from "./Header.module.css";

const Header = ({ username }) => {
  return (
    <header className={styles.header}>
      <h1>DecentraServe</h1>
      <h2>Technician DashBoard</h2>
      <h3>{username}</h3>
    </header>
  );
};

export default Header;
