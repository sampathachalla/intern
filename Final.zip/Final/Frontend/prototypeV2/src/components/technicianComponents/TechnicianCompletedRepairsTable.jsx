import React from "react";
import styles from "./TechnicianCompletedRepairsTable.module.css";

const TechnicianCompletedRepairsTable = ({ completedList }) => {
  return (
    <div className={styles.tableContainer}>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Service Repair ID</th>
            <th>Equipment Type</th>
            <th>Policy Number</th>
            <th>Service ID</th>
            <th>Equipment ID</th>
            <th>Customer Name</th>
            <th>Customer Phone</th>
            <th>Customer Email</th>
            <th>Customer Address</th>
            <th>Opening Date</th>
            <th>Closing Date</th>
            <th>Problem Description</th>
            <th>Issue</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {completedList.map((item, index) => (
            <tr key={index}>
              <td>{item.service_repair_id}</td>
              <td>{item.equipmentType}</td>
              <td>{item.policyNumber}</td>
              <td>{item.serviceID}</td>
              <td>{item.equipmentID}</td>
              <td>{item.customerName}</td>
              <td>{item.customerPhone}</td>
              <td>{item.customerEmail}</td>
              <td>{item.customerAddress}</td>
              <td>{item.openingDate}</td>
              <td>{item.closingDate}</td>
              <td>{item.problemDescription}</td>
              <td>{item.issue}</td>
              <td>{item.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TechnicianCompletedRepairsTable;
