import React, { useEffect, useState } from "react";
import axios from "axios";
import TechnicianPendingRepairsTable from "./TechnicianPendingRepairsTable";
import styles from "./TechnicianPendingRepairs.module.css";

const TechnicianPendingRepairs = ({ username }) => {
  const [pendingList, setPendingList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/technician/pending", {
        params: { username },
      })
      .then((response) => {
        setPendingList(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, [username]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.technicianPendingRepairs}>
      <h2>Pending Service Repairs</h2>
      <TechnicianPendingRepairsTable pendingList={pendingList} />
    </div>
  );
};

export default TechnicianPendingRepairs;
