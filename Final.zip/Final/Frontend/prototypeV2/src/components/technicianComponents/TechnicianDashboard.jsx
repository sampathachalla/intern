import React, { useState } from "react";
import Header from "./Header";
import TechnicianSidebar from "./TechnicianSidebar";
import TechnicianContentArea from "./TechnicianContentArea";
import styles from "./TechnicianDashboard.module.css";

const TechnicianDashboard = ({ username }) => {
  const [selectedSection, setSelectedSection] = useState("");

  return (
    <div className={styles.dashboard}>
      <Header className={styles.header} />
      <div className={styles.main}>
        <TechnicianSidebar onSelectSection={setSelectedSection} />
        <TechnicianContentArea section={selectedSection} username={username} />
      </div>
    </div>
  );
};

export default TechnicianDashboard;
