import React, { useState } from "react";
import styles from "./TechnicianPendingRepairsTable.module.css";
import axios from "axios";

const TechnicianPendingRepairsTable = ({ pendingList }) => {
  const [selectedRepair, setSelectedRepair] = useState(null);
  const [issue, setIssue] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleRepairClick = (repair) => {
    setSelectedRepair(repair);
  };

  const handleFormClose = () => {
    setSelectedRepair(null);
    setIssue("");
  };

  const handleSuccessMessageClose = () => {
    setSuccessMessage("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (selectedRepair && issue) {
      try {
        const response = await axios.post(
          "http://localhost:5000/api/technician/close_service_repair",
          {
            data: {
              service_repair_id: selectedRepair.service_repair_id,
              issue: issue,
            },
          }
        );
        if (response.status === 200) {
          setSuccessMessage("Service request closed successfully.");
          handleFormClose();
          // Optionally, refresh the list or handle the response
        }
      } catch (error) {
        console.error("Error submitting form:", error);
      }
    }
  };

  return (
    <div className={styles.tableContainer}>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Service Repair ID</th>
            <th>Equipment Type</th>
            <th>Policy Number</th>
            <th>Service ID</th>
            <th>Equipment ID</th>
            <th>Customer Name</th>
            <th>Customer Phone</th>
            <th>Customer Email</th>
            <th>Customer Address</th>
            <th>Opening Date</th>
            <th>Problem Description</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {pendingList.map((item, index) => (
            <tr key={index}>
              <td>{item.service_repair_id}</td>
              <td>{item.equipmentType}</td>
              <td>{item.policyNumber}</td>
              <td>{item.serviceID}</td>
              <td>{item.equipmentID}</td>
              <td>{item.customerName}</td>
              <td>{item.customerPhone}</td>
              <td>{item.customerEmail}</td>
              <td>{item.customerAddress}</td>
              <td>{item.openingDate}</td>
              <td>{item.problemDescription}</td>
              <td>{item.status}</td>
              <td>
                <button onClick={() => handleRepairClick(item)}>Action</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedRepair && (
        <div className={styles.formContainer}>
          <form onSubmit={handleSubmit}>
            <label>
              Issue:
              <input
                type="text"
                value={issue}
                onChange={(e) => setIssue(e.target.value)}
                required
              />
            </label>
            <button type="submit">Close Request</button>
            <button type="button" onClick={handleFormClose}>
              Cancel
            </button>
          </form>
        </div>
      )}

      {successMessage && (
        <div className={styles.successMessage}>
          {successMessage}
          <button
            onClick={handleSuccessMessageClose}
            className={styles.closeButton}
          >
            X
          </button>
        </div>
      )}
    </div>
  );
};

export default TechnicianPendingRepairsTable;
