import React, { useState } from "react";
import styles from "./TechnicianSidebar.module.css";

const TechnicianSidebar = ({ onSelectSection }) => {
  const [showServiceRepairs, setShowServiceRepairs] = useState(false);
  const [showPartsRequest, setShowPartsRequest] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  const handleSelectSection = (section) => {
    setActiveSection(section);
    onSelectSection(section);
  };

  const toggleServiceRepairs = () => setShowServiceRepairs(!showServiceRepairs);
  const togglePartsRequest = () => setShowPartsRequest(!showPartsRequest);

  return (
    <aside className={styles.sidebar}>
      <div>
        <h2 onClick={toggleServiceRepairs}>Service Repairs</h2>
        {showServiceRepairs && (
          <ul>
            <li
              className={activeSection === "ongoing" ? styles.selected : ""}
              onClick={() => handleSelectSection("ongoing")}
            >
              Ongoing
            </li>
            <li
              className={activeSection === "completed" ? styles.selected : ""}
              onClick={() => handleSelectSection("completed")}
            >
              Completed
            </li>
          </ul>
        )}
      </div>

      <div>
        <h2 onClick={togglePartsRequest}>Parts Request</h2>
        {showPartsRequest && (
          <ul>
            <li
              className={activeSection === "orderParts" ? styles.selected : ""}
              onClick={() => handleSelectSection("orderParts")}
            >
              Order Parts
            </li>
            <li
              className={activeSection === "orderStatus" ? styles.selected : ""}
              onClick={() => handleSelectSection("orderStatus")}
            >
              Order Status
            </li>
          </ul>
        )}
      </div>
    </aside>
  );
};

export default TechnicianSidebar;
