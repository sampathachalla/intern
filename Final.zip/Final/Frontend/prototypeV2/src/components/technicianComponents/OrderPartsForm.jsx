import React, { useState } from "react";
import axios from "axios";
import styles from "./OrderPartsForm.module.css";

const OrderPartsForm = ({ pendingRepairIds, username }) => {
  const [selectedRepairId, setSelectedRepairId] = useState("");
  const [equipmentType, setEquipmentType] = useState("");
  const [part, setPart] = useState("");
  const [count, setCount] = useState("");
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const partsList = [{ part, count }];

    const orderData = {
      username,
      serviceRepairId: selectedRepairId,
      equipmentType,
      partsList,
    };

    try {
      await axios.post(
        "http://localhost:5000/api/technician/order_parts",
        orderData
      );
      setOrderPlaced(true);
      setLoading(false);
      setSelectedRepairId("");
      setEquipmentType("");
      setPart("");
      setCount("");
    } catch (error) {
      console.error("Error placing order:", error);
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      {orderPlaced && (
        <div className={styles.overlay}>
          <div className={styles.orderPlacedMessage}>
            Order placed successfully!
            <button
              onClick={() => setOrderPlaced(false)}
              className={styles.refreshButton}
            >
              Place next order
            </button>
          </div>
        </div>
      )}
      {loading && (
        <div className={styles.loadingOverlay}>
          <div className={styles.loadingMessage}>Submitting...</div>
        </div>
      )}
      <form
        onSubmit={handleSubmit}
        className={`${styles.form} ${
          orderPlaced || loading ? styles.blurred : ""
        }`}
      >
        <h2 className={styles.heading}>Order Parts Form</h2>
        <div className={styles.formGroup}>
          <label htmlFor="repairId">Service Repair ID:</label>
          <select
            id="repairId"
            value={selectedRepairId}
            onChange={(e) => setSelectedRepairId(e.target.value)}
          >
            <option value="">Select Repair ID</option>
            {pendingRepairIds.map((id) => (
              <option key={id} value={id}>
                {id}
              </option>
            ))}
          </select>
        </div>
        <div className={styles.formGroup}>
          <label htmlFor="equipmentType">Equipment Type:</label>
          <input
            type="text"
            id="equipmentType"
            value={equipmentType}
            onChange={(e) => setEquipmentType(e.target.value)}
          />
        </div>
        <div className={styles.formGroup}>
          <label htmlFor="part">Part:</label>
          <input
            type="text"
            id="part"
            value={part}
            onChange={(e) => setPart(e.target.value)}
          />
        </div>
        <div className={styles.formGroup}>
          <label htmlFor="count">Count:</label>
          <input
            type="number"
            id="count"
            value={count}
            onChange={(e) => setCount(e.target.value)}
          />
        </div>
        <button
          type="submit"
          className={styles.submitButton}
          disabled={loading}
        >
          Order
        </button>
      </form>
    </div>
  );
};

export default OrderPartsForm;
