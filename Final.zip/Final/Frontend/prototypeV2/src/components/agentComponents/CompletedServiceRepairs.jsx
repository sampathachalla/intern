import React, { useEffect, useState } from "react";
import axios from "axios";
import CompletedServiceRepairsTable from "./CompletedServiceRepairsTable";
import styles from "./CompletedServiceRepairs.module.css";

const CompletedServiceRepairs = () => {
  const [completedList, setCompletedList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/agent/completed")
      .then((response) => {
        console.log("Response data:", response.data);
        setCompletedList(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.completedServiceRepairs}>
      <h2>Completed Service Repairs</h2>
      {completedList.length > 0 ? (
        <CompletedServiceRepairsTable completedList={completedList} />
      ) : (
        <p>No completed service repairs available.</p>
      )}
    </div>
  );
};

export default CompletedServiceRepairs;
