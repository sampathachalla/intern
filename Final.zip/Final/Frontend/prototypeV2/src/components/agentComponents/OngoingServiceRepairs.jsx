import React, { useEffect, useState } from "react";
import axios from "axios";
import OngoingServiceRepairsTable from "./OngoingServiceRepairsTable";
import styles from "./OngoingServiceRepairs.module.css";

const OngoingServiceRepairs = () => {
  const [ongoingList, setOngoingList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/agent/ongoing")
      .then((response) => {
        console.log("Response data:", response.data); // Debug log
        setOngoingList(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.ongoingServiceRepairs}>
      <h2>Ongoing Service Repairs</h2>
      {ongoingList.length > 0 ? (
        <OngoingServiceRepairsTable ongoingList={ongoingList} />
      ) : (
        <p>No ongoing service repairs available.</p>
      )}
    </div>
  );
};

export default OngoingServiceRepairs;
