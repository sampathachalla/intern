import React, { useEffect, useState } from "react";
import axios from "axios";
import TechnicianTable from "./TechnicianTable";
import styles from "./TechnicianDetails.module.css";

const TechnicianDetails = () => {
  const [technicians, setTechnicians] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/agent/technicians")
      .then((response) => {
        setTechnicians(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.technicianDetails}>
      <h2 className={styles.heading}>Technician Details</h2>
      {technicians.length > 0 ? (
        <TechnicianTable technicians={technicians} />
      ) : (
        <p className={styles.noData}>No technicians available.</p>
      )}
    </div>
  );
};

export default TechnicianDetails;
