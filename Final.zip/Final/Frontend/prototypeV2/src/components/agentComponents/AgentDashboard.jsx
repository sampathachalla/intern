import React, { useState } from "react";
import Header from "./Header";
import Sidebar from "./Sidebar";
import ContentArea from "./ContentArea";
import styles from "./AgentDashboard.module.css";

const AgentDashboard = ({ username }) => {
  const [selectedSection, setSelectedSection] = useState("stockDetails");

  return (
    <div className={styles.dashboard}>
      <Header className={styles.header} username={username} />
      <div className={styles.main}>
        <Sidebar
          onSelectSection={setSelectedSection}
          className={styles.sidebar}
        />
        <ContentArea section={selectedSection} className={styles.contentArea} />
      </div>
    </div>
  );
};

export default AgentDashboard;
