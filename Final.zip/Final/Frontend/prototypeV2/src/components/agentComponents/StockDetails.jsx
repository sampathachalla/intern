import React, { useEffect, useState } from "react";
import axios from "axios";
import StockDetailsTable from "./StockDetailsTable";
import styles from "./StockDetails.module.css";

const StockDetails = () => {
  const [totalEquipment, setTotalEquipment] = useState(0);
  const [warehouseCount, setWarehouseCount] = useState(0);
  const [customerCount, setCustomerCount] = useState(0);
  const [repairCount, setRepairCount] = useState(0);
  const [discardedCount, setDiscardedCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/agent/count_total_equipment")
      .then((response) => {
        if (response.data) {
          setTotalEquipment(response.data.total_equipment);
          setWarehouseCount(response.data.status_counts.warehouse || 0);
          setCustomerCount(response.data.status_counts.customer || 0);
          setRepairCount(response.data.status_counts.repair || 0);
          setDiscardedCount(response.data.status_counts.discarded || 0);
        }
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.stockDetails}>
      <h1 className={styles.heading}>Stock Details</h1>
      <div className={styles.centerCount}>
        <h2>Total Equipment: {totalEquipment}</h2>
      </div>
      <div className={styles.countsLine}>
        <div className={`${styles.countBox} ${styles.warehouse}`}>
          Warehouse: {warehouseCount}
        </div>
        <div className={`${styles.countBox} ${styles.discarded}`}>
          Discarded: {discardedCount}
        </div>
        <div className={`${styles.countBox} ${styles.customer}`}>
          Customer: {customerCount}
        </div>
      </div>
      <StockDetailsTable />
    </div>
  );
};

export default StockDetails;
