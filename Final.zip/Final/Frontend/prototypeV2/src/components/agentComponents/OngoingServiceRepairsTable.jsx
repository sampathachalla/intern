import React from "react";
import styles from "./OngoingServiceRepairsTable.module.css";
import OngoingServiceRepairsTableRow from "./OngoingServiceRepairsTableRow";

const OngoingServiceRepairsTable = ({ ongoingList }) => {
  return (
    <div className={styles.ongoingTableContainer}>
      <table className={styles.ongoingTable}>
        <thead>
          <tr>
            <th>Service Repair ID</th>
            <th>Policy Number</th>
            <th>Service ID</th>
            <th>Equipment ID</th>
            <th>Customer Name</th>
            <th>Customer Phone</th>
            <th>Customer Email</th>
            <th>Customer Address</th>
            <th>Technician Name</th>
            <th>Technician Email</th>
            <th>Technician Phone</th>
            <th>Rating</th>
            <th>Opening Date</th>
            <th>Closing Date</th>
            <th>Problem Description</th>
            <th>Issue</th>
            <th>Status</th>
            <th>Equipment Type</th>
          </tr>
        </thead>
        <tbody>
          {ongoingList.map((repair) => (
            <OngoingServiceRepairsTableRow
              key={repair.service_repair_id}
              repair={repair}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OngoingServiceRepairsTable;
