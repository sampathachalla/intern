import React from "react";
import styles from "./CompletedServiceRepairsTable.module.css";
import CompletedServiceRepairsTableRow from "./CompletedServiceRepairsTableRow";

const CompletedServiceRepairsTable = ({ completedList }) => {
  return (
    <div className={styles.completedTableContainer}>
      <table className={styles.completedTable}>
        <thead>
          <tr>
            <th>Service Repair ID</th>
            <th>Policy Number</th>
            <th>Service ID</th>
            <th>Equipment ID</th>
            <th>Customer Name</th>
            <th>Customer Phone</th>
            <th>Customer Email</th>
            <th>Customer Address</th>
            <th>Technician Name</th>
            <th>Technician Email</th>
            <th>Technician Phone</th>
            <th>Rating</th>
            <th>Opening Date</th>
            <th>Closing Date</th>
            <th>Problem Description</th>
            <th>Issue</th>
            <th>Status</th>
            <th>Equipment Type</th>
          </tr>
        </thead>
        <tbody>
          {completedList.map((repair) => (
            <CompletedServiceRepairsTableRow
              key={repair.service_repair_id}
              repair={repair}
            />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CompletedServiceRepairsTable;
