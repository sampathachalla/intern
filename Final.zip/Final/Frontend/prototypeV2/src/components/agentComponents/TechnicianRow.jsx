import React from "react";

const TechnicianRow = ({ technician }) => {
  return (
    <tr>
      <td>{technician.techId}</td>
      <td>{technician.technicianName}</td>
      <td>{technician.technicianEmail}</td>
      <td>{technician.technicianPhone}</td>
    </tr>
  );
};

export default TechnicianRow;
