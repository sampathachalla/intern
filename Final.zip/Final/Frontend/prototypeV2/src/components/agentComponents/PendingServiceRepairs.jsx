import React, { useEffect, useState } from "react";
import axios from "axios";
import PendingServiceRepairsTable from "./PendingServiceRepairsTable";
import styles from "./PendingServiceRepairs.module.css";

const PendingServiceRepairs = () => {
  const [pendingList, setPendingList] = useState([]);
  const [technicianList, setTechnicianList] = useState([]);
  const [selectedRepairs, setSelectedRepairs] = useState([]);
  const [selectedTechnician, setSelectedTechnician] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showMessage, setShowMessage] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [pendingResponse, technicianResponse] = await Promise.all([
          axios.get("http://localhost:5000/api/agent/pending"),
          axios.get("http://localhost:5000/api/agent/technicianID"),
        ]);

        setPendingList(pendingResponse.data);
        setTechnicianList(technicianResponse.data);
        setLoading(false);
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleSelectRepair = (repairId) => {
    setSelectedRepairs((prev) =>
      prev.includes(repairId)
        ? prev.filter((id) => id !== repairId)
        : [...prev, repairId]
    );
  };

  const handleAssign = async () => {
    try {
      await axios.post("http://localhost:5000/api/agent/assign", {
        technicianId: selectedTechnician,
        repairIds: selectedRepairs,
      });
      setShowMessage(true);
      // Optionally refetch data or update state to reflect changes
    } catch (error) {
      console.error("Error assigning technician:", error);
    }
  };

  const handleCloseMessage = () => {
    setShowMessage(false);
    setSelectedTechnician("");
    setSelectedRepairs([]);
    // Optionally refetch data or reset state to reflect changes
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.pendingServiceRepairs}>
      <h2>Pending Service Repairs</h2>
      {pendingList.length > 0 ? (
        <>
          <PendingServiceRepairsTable
            pendingList={pendingList}
            onSelectRepair={handleSelectRepair}
            selectedRepairs={selectedRepairs}
          />
          <div className={styles.assignContainer}>
            <select
              value={selectedTechnician}
              onChange={(e) => setSelectedTechnician(e.target.value)}
            >
              <option value="">Select Technician</option>
              {technicianList.map((techId) => (
                <option key={techId} value={techId}>
                  {techId}
                </option>
              ))}
            </select>
            <button onClick={handleAssign}>Assign</button>
          </div>
        </>
      ) : (
        <p>No pending service repairs available.</p>
      )}
      {showMessage && (
        <div className={styles.messageBox}>
          <p>Technician Assigned and changes will be reflected soon.</p>
          <button onClick={handleCloseMessage}>Close</button>
        </div>
      )}
    </div>
  );
};

export default PendingServiceRepairs;
