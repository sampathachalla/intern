import React from "react";
import EquipmentDetailsTableRow from "./EquipmentDetailsTableRow";
import styles from "./EquipmentDetailsTable.module.css";

const EquipmentDetailsTable = ({ equipmentList }) => {
  return (
    <table className={styles.equipmentTable}>
      <thead>
        <tr>
          <th>Equipment ID</th>
          <th>Type</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        {equipmentList.map((equipment, index) => (
          <EquipmentDetailsTableRow key={index} equipment={equipment} />
        ))}
      </tbody>
    </table>
  );
};

export default EquipmentDetailsTable;
