// src/components/userComponents/Sidebar.jsx
import React, { useState } from "react";
import styles from "./Sidebar.module.css";

const Sidebar = ({ onSelectSection }) => {
  const [showInventory, setShowInventory] = useState(false);
  const [showServiceRepair, setShowServiceRepair] = useState(false);
  const [showTechnician, setShowTechnician] = useState(false);
  const [showCustomers, setShowCustomers] = useState(false);
  const [activeSection, setActiveSection] = useState("");

  const handleSelectSection = (section) => {
    setActiveSection(section);
    onSelectSection(section);
  };

  const toggleInventory = () => setShowInventory(!showInventory);
  const toggleServiceRepair = () => setShowServiceRepair(!showServiceRepair);
  const toggleTechnician = () => setShowTechnician(!showTechnician);
  const toggleCustomers = () => setShowCustomers(!showCustomers);

  return (
    <aside className={styles.sidebar}>
      <div>
        <h2 onClick={toggleInventory}>Inventory</h2>
        {showInventory && (
          <ul>
            <li
              className={
                activeSection === "stockDetails" ? styles.selected : ""
              }
              onClick={() => handleSelectSection("stockDetails")}
            >
              Stock Details
            </li>
            <li
              className={
                activeSection === "equipmentDetails" ? styles.selected : ""
              }
              onClick={() => handleSelectSection("equipmentDetails")}
            >
              Equipment Details
            </li>
            <li
              className={activeSection === "getDetails" ? styles.selected : ""}
              onClick={() => handleSelectSection("getDetails")}
            >
              Get Details
            </li>
          </ul>
        )}
      </div>

      <div>
        <h2 onClick={toggleServiceRepair}>Service Repair</h2>
        {showServiceRepair && (
          <ul>
            <li
              className={activeSection === "pending" ? styles.selected : ""}
              onClick={() => handleSelectSection("pending")}
            >
              Pending
            </li>
            <li
              className={activeSection === "ongoing" ? styles.selected : ""}
              onClick={() => handleSelectSection("ongoing")}
            >
              Ongoing
            </li>
            <li
              className={activeSection === "completed" ? styles.selected : ""}
              onClick={() => handleSelectSection("completed")}
            >
              Completed
            </li>
          </ul>
        )}
      </div>

      <div>
        <h2 onClick={toggleTechnician}>Technician</h2>
        {showTechnician && (
          <ul>
            <li
              className={
                activeSection === "technicianDetails" ? styles.selected : ""
              }
              onClick={() => handleSelectSection("technicianDetails")}
            >
              Technician Details
            </li>
            <li
              className={
                activeSection === "getTechnicianDetails" ? styles.selected : ""
              }
              onClick={() => handleSelectSection("getTechnicianDetails")}
            >
              Get Details
            </li>
          </ul>
        )}
      </div>

      <div>
        <h2 onClick={toggleCustomers}>Customers</h2>
        {showCustomers && (
          <ul>
            <li
              className={
                activeSection === "customerOverview" ? styles.selected : ""
              }
              onClick={() => handleSelectSection("customerOverview")}
            >
              Customer Overview
            </li>
            <li
              className={
                activeSection === "getCustomerDetails" ? styles.selected : ""
              }
              onClick={() => handleSelectSection("getCustomerDetails")}
            >
              Get Details
            </li>
          </ul>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
