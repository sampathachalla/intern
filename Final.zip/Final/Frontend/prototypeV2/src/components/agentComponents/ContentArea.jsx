// src/components/userComponents/ContentArea.jsx
import React from "react";
import styles from "./ContentArea.module.css";
import EquipmentDetails from "./EquipmentDetails";
import PendingServiceRepairs from "./PendingServiceRepairs";
import StockDetails from "./StockDetails";
import OngoingServiceRepairs from "./OngoingServiceRepairs";
import CompletedServiceRepairs from "./CompletedServiceRepairs";
import TechnicianDetails from "./TechnicianDetails";
import CustomerDetails from "./CustomerDetails";
import GetTechnicianDetails from "./GetTechnicianDetails";
import GetCustomerDetails from "./GetCustomerDetails";
import GetEquipmentDetails from "./GetEquipmentDetails";

const ContentArea = ({ section }) => {
  let content;
  switch (section) {
    case "stockDetails":
      content = <StockDetails />;
      break;
    case "equipmentDetails":
      content = <EquipmentDetails />;
      break;
    case "getDetails":
      content = <GetEquipmentDetails />;
      break;
    case "pending":
      content = <PendingServiceRepairs />;
      break;
    case "ongoing":
      content = <OngoingServiceRepairs />;
      break;
    case "completed":
      content = <CompletedServiceRepairs />;
      break;
    case "technicianDetails":
      content = <TechnicianDetails />;
      break;
    case "getTechnicianDetails":
      content = <GetTechnicianDetails />;
      break;
    case "customerOverview":
      content = <CustomerDetails />;
      break;
    case "getCustomerDetails":
      content = <GetCustomerDetails />;
      break;
    default:
      content = <div>Select a section from the sidebar</div>;
  }

  return (
    <div className={styles.contentArea}>
      <main>{content}</main>
    </div>
  );
};

export default ContentArea;
