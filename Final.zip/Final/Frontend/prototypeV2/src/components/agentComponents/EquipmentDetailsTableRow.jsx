import React from "react";
import styles from "./EquipmentDetailsTableRow.module.css";

const EquipmentDetailsTableRow = ({ equipment }) => {
  return (
    <tr>
      <td>{equipment.equipmentID}</td>
      <td>{equipment.type}</td>
      <td>{equipment.status}</td>
    </tr>
  );
};

export default EquipmentDetailsTableRow;
