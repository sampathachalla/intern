import React, { useState } from "react";
import axios from "axios";
import styles from "./GetEquipmentDetails.module.css";

const GetEquipmentDetails = () => {
  const [equipmentId, setEquipmentId] = useState("");
  const [equipmentDetails, setEquipmentDetails] = useState(null);
  const [error, setError] = useState(null);

  const handleInputChange = (event) => {
    setEquipmentId(event.target.value);
  };

  const handleGetDetails = () => {
    axios
      .get(
        `http://localhost:5000/api/agent/equipment_details?equipmentId=${equipmentId}`
      )
      .then((response) => {
        setEquipmentDetails(response.data);
        setError(null);
      })
      .catch((error) => {
        setError(
          error.response ? error.response.data.error : "Error fetching data"
        );
        setEquipmentDetails(null);
      });
  };

  return (
    <div className={styles.container}>
      <h2>Get Equipment Details</h2>
      <div className={styles.inputGroup}>
        <input
          type="text"
          value={equipmentId}
          onChange={handleInputChange}
          placeholder="Enter Equipment ID"
          className={styles.input}
        />
        <button onClick={handleGetDetails} className={styles.button}>
          Get Details
        </button>
      </div>
      {error && <div className={styles.error}>{error}</div>}
      {equipmentDetails && (
        <div className={styles.details}>
          <div className={styles.detailBox}>
            <h3>Type</h3>
            <p className={styles.type}>{equipmentDetails.type}</p>
          </div>
          <div className={styles.detailBox}>
            <h3>Repair Count</h3>
            <p>{equipmentDetails.repairCount}</p>
          </div>
          <div className={styles.detailBox}>
            <h3>Major Issue</h3>
            <p>{equipmentDetails.majorIssue}</p>
          </div>
          <div className={styles.detailBox}>
            <h3>Current Location</h3>
            <p>{equipmentDetails.currentLocation}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default GetEquipmentDetails;
