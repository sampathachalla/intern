import React, { useEffect, useState } from "react";
import axios from "axios";
import CustomerTable from "./CustomerTable";
import styles from "./CustomerDetails.module.css";

const CustomerDetails = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/agent/customers")
      .then((response) => {
        setCustomers(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.customerDetails}>
      <h2 className={styles.heading}>Customer Details</h2>
      {customers.length > 0 ? (
        <CustomerTable customers={customers} />
      ) : (
        <p>No customers available.</p>
      )}
    </div>
  );
};

export default CustomerDetails;
