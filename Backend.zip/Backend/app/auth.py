from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import zmq
import json

auth_blueprint = Blueprint('auth', __name__)

context = zmq.Context()
socket = context.socket(zmq.REQ)
socket.connect("tcp://localhost:5560")  # Adjust the port if needed

def server_request(action, payload):
    request_data = json.dumps({"action": action, **payload}).encode('utf-8')
    socket.send(request_data)
    response = socket.recv()
    return json.loads(response.decode('utf-8'))

@auth_blueprint.route('/login', methods=['OPTIONS', 'POST'])
@cross_origin()
def login():
    if request.method == 'OPTIONS':
        return jsonify({'success': True}), 200

    data = request.get_json()
    user_type = data.get('userType')
    username = data.get('username')
    password = data.get('password')

    # Call the server to verify credentials
    response = server_request('verify_credential', {'username': username, 'password': password, 'usertype': user_type})

    if response.get('verified'):
        return jsonify({'success': True}), 200
    else:
        return jsonify({'success': False, 'message': 'Invalid credentials'}), 401

@auth_blueprint.route('/signup', methods=['OPTIONS', 'POST'])
@cross_origin()
def signup():
    if request.method == 'OPTIONS':
        return jsonify({'success': True}), 200

    data = request.get_json()
    user_type = data.get('userType')
    username = data.get('username')
    password = data.get('password')

    # Basic validation
    if not user_type or not username or not password:
        return jsonify({'success': False, 'message': 'All fields are required'}), 400

    if user_type not in ['user', 'agent', 'technician']:
        return jsonify({'success': False, 'message': 'Invalid user type'}), 400

    # Check if the username already exists by loading all credentials
    response = server_request('load_credentials', {})
    if isinstance(response, dict) and response.get("status") == "success":
        credentials = response.get("data", [])
        if any(user['username'] == username for user in credentials):
            return jsonify({'success': False, 'message': 'Username already exists'}), 400

        # Add new user by calling the server
        server_request('add_credential', {'usertype': user_type, 'username': username, 'password': password})

        return jsonify({'success': True, 'message': 'User registered successfully'}), 201
    else:
        return jsonify({'success': False, 'message': 'Failed to load credentials'}), 500
