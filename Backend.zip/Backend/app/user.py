from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import zmq
import json
import logging

# Set up logging
logging.basicConfig(level=logging.DEBUG)

user_blueprint = Blueprint('user', __name__)

context = zmq.Context()
socket = context.socket(zmq.REQ)
socket.connect("tcp://localhost:5560")  # Adjust the port if needed

# Simulate the in-memory dictionary for equipment names
equipment_names = {}

def server_request(action, payload):
    request_data = json.dumps({"action": action, **payload}).encode('utf-8')
    socket.send(request_data)
    response = socket.recv()
    return json.loads(response.decode('utf-8'))

@user_blueprint.route('/fetch_user_details', methods=['OPTIONS', 'POST'])
@cross_origin()
def fetch_user_details():
    if request.method == 'OPTIONS':
        return jsonify({'success': True}), 200

    data = request.get_json()
    username = data.get('username')

    if not username:
        return jsonify({'success': False, 'message': 'Username is required'}), 400

    logging.debug(f"Fetching details for user: {username}")
    response = server_request('fetch_user_details', {'username': username})

    if 'customer_id' in response:
        # Initialize default names if not present
        for equipment in response['equipment_details_list']:
            if equipment['equipment_id'] not in equipment_names:
                equipment_names[equipment['equipment_id']] = f"Default Name {equipment['equipment_id']}"
            equipment['name'] = equipment_names[equipment['equipment_id']]

        # Create a name to ID mapping
        name_to_id_mapping = {name: id for id, name in equipment_names.items()}

        # Add name_to_id_mapping to the response
        response['name_to_id_mapping'] = name_to_id_mapping

        logging.debug(f"Fetched details: {response}")
        return jsonify(response), 200
    else:
        logging.error("User details not found")
        return jsonify({'success': False, 'message': 'User details not found'}), 404

@user_blueprint.route('/update_equipment_name', methods=['OPTIONS', 'POST'])
@cross_origin()
def update_equipment_name():
    if request.method == 'OPTIONS':
        return jsonify({'success': True}), 200

    data = request.get_json()
    equipment_id = data.get('equipment_id')
    new_name = data.get('new_name')

    if not equipment_id or not new_name:
        return jsonify({'success': False, 'message': 'Equipment ID and new name are required'}), 400

    logging.debug(f"Updating equipment {equipment_id} name to {new_name}")

    # Update the name in the backend dictionary
    equipment_names[equipment_id] = new_name

    logging.debug(f"Updated equipment names: {equipment_names}")

    return jsonify({'success': True, 'message': 'Equipment name updated'}), 200

@user_blueprint.route('/report_problem', methods=['OPTIONS', 'POST'])
@cross_origin()
def report_problem():
    if request.method == 'OPTIONS':
        return jsonify({'success': True}), 200

    data = request.get_json()
    equipment_id = data.get('equipment_id')
    problem_description = data.get('problem_description')

    if not equipment_id or not problem_description:
        return jsonify({'success': False, 'message': 'Equipment ID and problem description are required'}), 400

    logging.debug(f"Reporting problem for equipment {equipment_id}: {problem_description}")

    # Call the server function to add a service repair
    response = server_request('add_service_repair', {'data': {'equipment_id': equipment_id, 'problem_description': problem_description}})

    if response.get('status') == 'success':
        logging.debug(f"Problem reported successfully: {response.get('message')}")
        return jsonify({'success': True, 'message': response.get('message', 'Problem reported successfully')}), 200
    else:
        logging.error(f"Failed to report problem: {response.get('message', 'Unknown error')}")
        return jsonify({'success': False, 'message': response.get('message', 'Failed to report problem')}), 500

@user_blueprint.route('/add_service', methods=['OPTIONS', 'POST'])
@cross_origin()
def add_service():
    if request.method == 'OPTIONS':
        return jsonify({'success': True}), 200

    data = request.get_json()
    username = data.get('username')
    service_type = data.get('service_type')
    email = data.get('email')
    phone = data.get('phone')
    address = data.get('address')

    if not username or not service_type or not email or not phone or not address:
        return jsonify({'success': False, 'message': 'All fields are required'}), 400

    logging.debug(f"Adding service for user {username} with type {service_type}")

    # Call the server function to add a new service
    response = server_request('add_service', {
        'username': username,
        'service_type': service_type,
        'email': email,
        'phone': phone,
        'address': address
    })

    if response.get('status') == 'success':
        logging.debug(f"Service added successfully: {response.get('message')}")
        return jsonify({'success': True, 'message': response.get('message', 'Service added successfully')}), 200
    else:
        logging.error(f"Failed to add service: {response.get('message', 'Unknown error')}")
        return jsonify({'success': False, 'message': response.get('message', 'Failed to add service')}), 500
    


@user_blueprint.route('/update_rating', methods=['OPTIONS', 'POST'])
@cross_origin()
def update_rating():
    if request.method == 'OPTIONS':
        return jsonify({'success': True}), 200

    data = request.get_json()
    action = data.get('action')
    service_repair_id = data.get('service_repair_id')
    rating = data.get('rating')

    if action == "add_rating" and service_repair_id and rating:
        response = server_request(action, {
            "service_repair_id": service_repair_id,
            "rating": rating
        })
        if response.get('status') == 'success':
            return jsonify({'success': True, 'message': response.get('message')}), 200
        else:
            return jsonify({'success': False, 'message': response.get('message')}), 500
    else:
        return jsonify({'success': False, 'message': 'Invalid request'}), 400