import React from "react";
import styles from "./companyInfo.module.css";

const CompanyInfo = () => {
  return (
    <div className={styles.companyInfo}>
      <h1>DecentraServe</h1>
      <p>
        Welcome to <span className={styles.highlight}>DecentraServe</span>,
        where we bring decentralized solutions to serve your needs. Experience
        the future of technology today.
      </p>
    </div>
  );
};

export default CompanyInfo;
