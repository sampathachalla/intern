// src/components/agentComponents/TechnicianTable.jsx
import React from "react";
import TechnicianRow from "./TechnicianRow";
import styles from "./TechnicianTable.module.css";

const TechnicianTable = ({ technicians }) => {
  return (
    <div className={styles.tableContainer}>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Technician ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
          </tr>
        </thead>
        <tbody>
          {technicians.map((technician) => (
            <TechnicianRow key={technician.techId} technician={technician} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TechnicianTable;
