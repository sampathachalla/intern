import React, { useEffect, useState } from "react";
import axios from "axios";
import PendingServiceRepairsTable from "./PendingServiceRepairsTable";
import styles from "./PendingServiceRepairs.module.css";

const PendingServiceRepairs = () => {
  const [pendingList, setPendingList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/agent/pending")
      .then((response) => {
        console.log("Response data:", response.data); // Debug log
        setPendingList(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.pendingServiceRepairs}>
      <h2>Pending Service Repairs</h2>
      {pendingList.length > 0 ? (
        <PendingServiceRepairsTable pendingList={pendingList} />
      ) : (
        <p>No pending service repairs available.</p>
      )}
    </div>
  );
};

export default PendingServiceRepairs;
