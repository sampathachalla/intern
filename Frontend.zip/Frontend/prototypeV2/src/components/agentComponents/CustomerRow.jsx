import React from "react";

const CustomerRow = ({ customer }) => {
  return (
    <tr>
      <td>{customer.customerId}</td>
      <td>{customer.name}</td>
      <td>{customer.email}</td>
      <td>{customer.phone}</td>
      <td>{customer.address}</td>
      <td>{customer.serviceIDs.join(", ")}</td>
    </tr>
  );
};

export default CustomerRow;
