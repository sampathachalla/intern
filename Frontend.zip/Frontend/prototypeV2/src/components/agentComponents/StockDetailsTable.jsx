import React, { useEffect, useState } from "react";
import axios from "axios";
import styles from "./StockDetailsTable.module.css";

const StockDetailsTable = () => {
  const [equipmentByType, setEquipmentByType] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/agent/count_equipment_by_type")
      .then((response) => {
        if (response.data) {
          setEquipmentByType(response.data.type_counts || []);
        }
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.equipmentByType}>
      <h2 className={styles.Tableheading}>Equipment Count</h2>
      <table>
        <thead>
          <tr>
            <th>Type</th>
            <th>Warehouse</th>
            <th>Customer</th>
            <th>Repair</th>
            <th>Discarded</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          {equipmentByType.map((item, index) => (
            <tr key={index}>
              <td>{item.type}</td>
              <td>{item.warehouse}</td>
              <td>{item.customer}</td>
              <td>{item.repair}</td>
              <td>{item.discarded}</td>
              <td>
                {item.warehouse + item.customer + item.repair + item.discarded}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StockDetailsTable;
