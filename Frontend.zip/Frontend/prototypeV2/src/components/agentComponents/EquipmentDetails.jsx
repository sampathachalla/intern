import React, { useEffect, useState } from "react";
import axios from "axios";
import EquipmentDetailsTable from "./EquipmentDetailsTable";
import styles from "./EquipmentDetails.module.css";

const EquipmentDetails = () => {
  const [equipmentList, setEquipmentList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/agent/equipment")
      .then((response) => {
        setEquipmentList(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.equipmentDetails}>
      <h2>Equipment Details</h2>
      {equipmentList.length > 0 ? (
        <EquipmentDetailsTable equipmentList={equipmentList} />
      ) : (
        <p>No equipment details available.</p>
      )}
    </div>
  );
};

export default EquipmentDetails;
