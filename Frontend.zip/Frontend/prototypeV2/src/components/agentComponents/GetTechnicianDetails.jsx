import React, { useState } from "react";
import axios from "axios";
import styles from "./GetTechnicianDetails.module.css";

const GetTechnicianDetails = () => {
  const [technicianId, setTechnicianId] = useState("");
  const [technicianDetails, setTechnicianDetails] = useState(null);
  const [error, setError] = useState(null);

  const handleInputChange = (event) => {
    setTechnicianId(event.target.value);
  };

  const handleGetDetails = () => {
    axios
      .get(
        `http://localhost:5000/api/agent/technician_performance?technicianId=${technicianId}`
      )
      .then((response) => {
        setTechnicianDetails(response.data);
        setError(null);
      })
      .catch((error) => {
        setError(
          error.response ? error.response.data.error : "Error fetching data"
        );
        setTechnicianDetails(null);
      });
  };

  return (
    <div className={styles.container}>
      <h2>Get Technician Details</h2>
      <div className={styles.inputGroup}>
        <input
          type="text"
          value={technicianId}
          onChange={handleInputChange}
          placeholder="Enter Technician ID"
          className={styles.input}
        />
        <button onClick={handleGetDetails} className={styles.button}>
          Get Details
        </button>
      </div>
      {error && <div className={styles.error}>{error}</div>}
      {technicianDetails && (
        <div className={styles.details}>
          <div className={styles.detailBox}>
            <h3>Technician Name</h3>
            <p>{technicianDetails.technicianName}</p>
          </div>
          <div className={styles.detailBox}>
            <h3>Average Rating</h3>
            <p>{technicianDetails.averageRating}</p>
          </div>
          <div className={styles.detailBox}>
            <h3>Average Service Time</h3>
            <p>{technicianDetails.averageServiceTime}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default GetTechnicianDetails;
