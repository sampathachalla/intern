import React, { useState } from "react";
import axios from "axios";
import styles from "./GetCustomerDetails.module.css";

const GetCustomerDetails = () => {
  const [customerId, setCustomerId] = useState("");
  const [customerDetails, setCustomerDetails] = useState(null);
  const [error, setError] = useState(null);

  const handleInputChange = (event) => {
    setCustomerId(event.target.value);
  };

  const handleGetDetails = () => {
    axios
      .get(
        `http://localhost:5000/api/agent/customer_details?customerId=${customerId}`
      )
      .then((response) => {
        setCustomerDetails(response.data);
        setError(null);
      })
      .catch((error) => {
        setError(
          error.response ? error.response.data.error : "Error fetching data"
        );
        setCustomerDetails(null);
      });
  };

  return (
    <div className={styles.container}>
      <h2>Get Customer Details</h2>
      <div className={styles.inputGroup}>
        <input
          type="text"
          value={customerId}
          onChange={handleInputChange}
          placeholder="Enter Customer ID"
          className={styles.input}
        />
        <button onClick={handleGetDetails} className={styles.button}>
          Get Details
        </button>
      </div>
      {error && <div className={styles.error}>{error}</div>}
      {customerDetails && (
        <div className={styles.details}>
          <div className={styles.detailRow}>
            <div className={styles.detailBox}>
              <h3>Name</h3>
              <p>{customerDetails.name}</p>
            </div>
            <div className={styles.detailBox}>
              <h3>Phone</h3>
              <p>{customerDetails.phone}</p>
            </div>
            <div className={styles.detailBox}>
              <h3>Email</h3>
              <p>{customerDetails.email}</p>
            </div>
          </div>
          <div className={styles.detailBox}>
            <h3>Address</h3>
            <p>{customerDetails.address}</p>
          </div>
          <h3>Equipment Details</h3>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Equipment ID</th>
                <th>Type</th>
              </tr>
            </thead>
            <tbody>
              {customerDetails.equipmentDetails.map((equipment) => (
                <tr key={equipment.equipmentID}>
                  <td>{equipment.equipmentID}</td>
                  <td>{equipment.type}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <h3>Service Repair Details</h3>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Service Repair ID</th>
                <th>Equipment ID</th>
                <th>Technician Name</th>
                <th>Technician Email</th>
                <th>Technician Phone</th>
                <th>Rating</th>
                <th>Opening Date</th>
                <th>Closing Date</th>
                <th>Problem Description</th>
                <th>Issue</th>
                <th>Status</th>
                <th>Equipment Type</th>
              </tr>
            </thead>
            <tbody>
              {customerDetails.serviceRepairDetails.map((repair) => (
                <tr key={repair.serviceRepairID}>
                  <td>{repair.serviceRepairID}</td>
                  <td>{repair.equipmentID}</td>
                  <td>{repair.technicianName}</td>
                  <td>{repair.technicianEmail}</td>
                  <td>{repair.technicianPhone}</td>
                  <td>{repair.rating}</td>
                  <td>{repair.openingDate}</td>
                  <td>{repair.closingDate}</td>
                  <td>{repair.problemDescription}</td>
                  <td>{repair.issue}</td>
                  <td>{repair.status}</td>
                  <td>{repair.equipmentType}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default GetCustomerDetails;
