import React from "react";
import CustomerRow from "./CustomerRow";
import styles from "./CustomerTable.module.css";

const CustomerTable = ({ customers }) => {
  return (
    <div className={styles.tableContainer}>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Customer ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Service IDs</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((customer) => (
            <CustomerRow key={customer.customerId} customer={customer} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default CustomerTable;
