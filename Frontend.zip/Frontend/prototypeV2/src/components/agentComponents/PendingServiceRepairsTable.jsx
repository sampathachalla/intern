// PendingServiceRepairsTable.jsx
import React from "react";
import PendingServiceRepairsTableRow from "./PendingServiceRepairsTableRow";
import styles from "./PendingServiceRepairsTable.module.css";

const PendingServiceRepairsTable = ({ pendingList }) => {
  return (
    <div className={styles.pendingTableContainer}>
      <table className={styles.pendingTable}>
        <thead>
          <tr>
            <th>Service Repair ID</th>
            <th>Policy Number</th>
            <th>Service ID</th>
            <th>Equipment ID</th>
            <th>Customer Name</th>
            <th>Customer Phone</th>
            <th>Customer Email</th>
            <th>Customer Address</th>
            <th>Technician Name</th>
            <th>Technician Email</th>
            <th>Technician Phone</th>
            <th>Rating</th>
            <th>Opening Date</th>
            <th>Closing Date</th>
            <th>Problem Description</th>
            <th>Issue</th>
            <th>Status</th>
            <th>Equipment Type</th>
          </tr>
        </thead>
        <tbody>
          {pendingList.map((repair, index) => (
            <PendingServiceRepairsTableRow key={index} repair={repair} />
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PendingServiceRepairsTable;
