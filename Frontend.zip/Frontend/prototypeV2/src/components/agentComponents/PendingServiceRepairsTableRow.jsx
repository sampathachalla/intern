// PendingServiceRepairsTableRow.js
import React from "react";
import styles from "./PendingServiceRepairsTableRow.module.css";

const PendingServiceRepairsTableRow = ({ repair }) => {
  console.log("Repair item:", repair); // Debug log

  return (
    <tr>
      <td>{repair.service_repair_id}</td>
      <td>{repair.policyNumber}</td>
      <td>{repair.serviceID}</td>
      <td>{repair.equipmentID}</td>
      <td>{repair.customerName}</td>
      <td>{repair.customerPhone}</td>
      <td>{repair.customerEmail}</td>
      <td>{repair.customerAddress}</td>
      <td>{repair.technicianName}</td>
      <td>{repair.technicianEmail}</td>
      <td>{repair.technicianPhone}</td>
      <td>{repair.rating}</td>
      <td>{repair.openingDate}</td>
      <td>{repair.closingDate}</td>
      <td>{repair.problemDescription}</td>
      <td>{repair.issue}</td>
      <td>{repair.status}</td>
      <td>{repair.equipmentType}</td>
    </tr>
  );
};

export default PendingServiceRepairsTableRow;
