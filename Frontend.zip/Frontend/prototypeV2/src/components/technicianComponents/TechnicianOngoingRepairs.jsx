import React, { useEffect, useState } from "react";
import axios from "axios";
import TechnicianOngoingRepairsTable from "./TechnicianOngoingRepairsTable";
import styles from "./TechnicianOngoingRepairs.module.css";

const TechnicianOngoingRepairs = ({ username }) => {
  const [ongoingList, setOngoingList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/technician/ongoing", {
        params: { username },
      })
      .then((response) => {
        setOngoingList(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, [username]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.technicianOngoingRepairs}>
      <h2>Ongoing Service Repairs</h2>
      <TechnicianOngoingRepairsTable ongoingList={ongoingList} />
    </div>
  );
};

export default TechnicianOngoingRepairs;
