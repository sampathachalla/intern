import React, { useEffect, useState } from "react";
import axios from "axios";
import styles from "./OrderPartsTable.module.css";

const OrderPartsTable = () => {
  const [orderParts, setOrderParts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/technician/order_parts")
      .then((response) => {
        setOrderParts(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, []);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.tableContainer}>
      <h2 className={styles.heading}>Parts Order Status</h2>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Technician ID</th>
            <th>Service Repair ID</th>
            <th>Equipment Type</th>
            <th>Parts List</th>
            <th>Ordered Date</th>
            <th>Status</th>
            <th>Delivery Date</th>
          </tr>
        </thead>
        <tbody>
          {orderParts.map((order) => (
            <tr key={order.order_id}>
              <td>{order.order_id}</td>
              <td>{order.technicianId}</td>
              <td>{order.serviceRepairId}</td>
              <td>{order.equipmentType}</td>
              <td>
                {order.partsList.map((part, index) => (
                  <div key={index}>
                    {part.part} (x{part.count})
                  </div>
                ))}
              </td>
              <td>{order.orderedDate}</td>
              <td>{order.status}</td>
              <td>{order.deliveryDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrderPartsTable;
