import React, { useEffect, useState } from "react";
import axios from "axios";
import TechnicianCompletedRepairsTable from "./TechnicianCompletedRepairsTable";
import styles from "./TechnicianCompletedRepairs.module.css";

const TechnicianCompletedRepairs = ({ username }) => {
  const [completedList, setCompletedList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/technician/completed", {
        params: { username },
      })
      .then((response) => {
        setCompletedList(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setLoading(false);
      });
  }, [username]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className={styles.technicianCompletedRepairs}>
      <h2>Completed Service Repairs</h2>
      <TechnicianCompletedRepairsTable completedList={completedList} />
    </div>
  );
};

export default TechnicianCompletedRepairs;
