import React, { useState } from "react";
import axios from "axios";
import styles from "./UserService.module.css";

const UserService = ({ nameToIdMapping }) => {
  const [selectedEquipment, setSelectedEquipment] = useState("");
  const [problemDescription, setProblemDescription] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const equipmentId = nameToIdMapping[selectedEquipment];

    try {
      const response = await axios.post(
        "http://localhost:5000/api/user/report_problem",
        {
          equipment_id: equipmentId,
          problem_description: problemDescription,
        }
      );
      console.log("Problem reported successfully:", response.data);
    } catch (err) {
      console.error("Error reporting problem:", err);
    }
  };

  return (
    <div className={styles.container}>
      <h2 className={styles.heading}>Service Request</h2>
      <form onSubmit={handleSubmit} className={styles.form}>
        <div className={styles.formGroup}>
          <label htmlFor="equipment" className={styles.label}>
            Select Equipment:
          </label>
          <select
            id="equipment"
            value={selectedEquipment}
            onChange={(e) => setSelectedEquipment(e.target.value)}
            className={styles.input}
          >
            <option value="" disabled>
              Select Equipment
            </option>
            {Object.keys(nameToIdMapping).map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>
        <div className={styles.formGroup}>
          <label htmlFor="problemDescription" className={styles.label}>
            Problem Description:
          </label>
          <input
            type="text"
            id="problemDescription"
            value={problemDescription}
            onChange={(e) => setProblemDescription(e.target.value)}
            className={styles.input}
          />
        </div>
        <button type="submit" className={styles.submitButton}>
          Submit
        </button>
      </form>
    </div>
  );
};

export default UserService;
