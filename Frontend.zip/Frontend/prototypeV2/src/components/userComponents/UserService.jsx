import React, { useState } from "react";
import axios from "axios";
import styles from "./UserService.module.css";
import AddServiceForm from "./AddServiceForm";

const UserService = ({ nameToIdMapping, username }) => {
  const [selectedForm, setSelectedForm] = useState("serviceRequest");
  const [selectedEquipment, setSelectedEquipment] = useState("");
  const [problemDescription, setProblemDescription] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const equipmentId = nameToIdMapping[selectedEquipment];

    try {
      const response = await axios.post(
        "http://localhost:5000/api/user/report_problem",
        {
          username,
          equipment_id: equipmentId,
          problem_description: problemDescription,
        }
      );
      setSuccessMessage(
        "Service request submitted successfully. A technician will reach out soon."
      );
      setSelectedEquipment("");
      setProblemDescription("");
    } catch (err) {
      console.error("Error reporting problem:", err);
    }
  };

  const closeSuccessMessage = () => {
    setSuccessMessage("");
  };

  return (
    <div className={styles.container}>
      <h2 className={styles.heading}>Service Options</h2>
      <div className={styles.buttonGroup}>
        <button
          onClick={() => setSelectedForm("serviceRequest")}
          className={styles.switchButton}
        >
          Service Request Form
        </button>
        <button
          onClick={() => setSelectedForm("addService")}
          className={styles.switchButton}
        >
          Add Service Form
        </button>
      </div>
      {selectedForm === "serviceRequest" && (
        <div>
          <h2 className={styles.heading}>Service Request</h2>
          {successMessage && (
            <div className={styles.successMessage}>
              {successMessage}
              <button
                onClick={closeSuccessMessage}
                className={styles.closeButton}
              >
                X
              </button>
            </div>
          )}
          <form onSubmit={handleSubmit} className={styles.form}>
            <div className={styles.formGroup}>
              <label htmlFor="equipment" className={styles.label}>
                Select Equipment:
              </label>
              <select
                id="equipment"
                value={selectedEquipment}
                onChange={(e) => setSelectedEquipment(e.target.value)}
                className={styles.input}
              >
                <option value="" disabled>
                  Select Equipment
                </option>
                {Object.keys(nameToIdMapping).map((name) => (
                  <option key={name} value={name}>
                    {name}
                  </option>
                ))}
              </select>
            </div>
            <div className={styles.formGroup}>
              <label htmlFor="problemDescription" className={styles.label}>
                Problem Description:
              </label>
              <input
                type="text"
                id="problemDescription"
                value={problemDescription}
                onChange={(e) => setProblemDescription(e.target.value)}
                className={styles.input}
              />
            </div>
            <button type="submit" className={styles.submitButton}>
              Submit
            </button>
          </form>
        </div>
      )}
      {selectedForm === "addService" && <AddServiceForm username={username} />}
    </div>
  );
};

export default UserService;
