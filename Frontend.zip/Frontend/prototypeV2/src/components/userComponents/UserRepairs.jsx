import React, { useState } from "react";
import styles from "./UserRepairs.module.css";

const UserRepairs = ({ repairDetails, nameToIdMapping }) => {
  const [filterStatus, setFilterStatus] = useState("all");

  const handleFilterChange = (status) => {
    setFilterStatus(status);
  };

  const filteredRepairs = repairDetails.filter((repair) => {
    if (filterStatus === "all") return true;
    return repair.status === filterStatus;
  });

  return (
    <div className={styles.container}>
      <h2 className={styles.heading}>Repair Details</h2>
      <div className={styles.buttonContainer}>
        <button
          className={styles.button}
          onClick={() => handleFilterChange("ongoing")}
        >
          Ongoing
        </button>
        <button
          className={styles.button}
          onClick={() => handleFilterChange("pending")}
        >
          Pending
        </button>
        <button
          className={styles.button}
          onClick={() => handleFilterChange("completed")}
        >
          Completed
        </button>
        <button
          className={styles.button}
          onClick={() => handleFilterChange("all")}
        >
          All
        </button>
      </div>
      <div className={styles.tableContainer}>
        <table className={styles.repairTable}>
          <thead>
            <tr>
              <th>Service Repair ID</th>
              <th>Equipment Type</th>
              <th>Default Name</th>
              <th>Equipment ID</th>
              <th>Technician Name</th>
              <th>Technician Phone</th>
              <th>Technician Email</th>
              <th>Rating</th>
              <th>Opening Date</th>
              <th>Closing Date</th>
              <th>Problem Description</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {filteredRepairs.map((repair) => (
              <tr key={repair.service_repair_id}>
                <td>{repair.service_repair_id}</td>
                <td>{repair.equipment_type}</td>
                <td>{nameToIdMapping[repair.equipment_id] || "N/A"}</td>
                <td>{repair.equipment_id}</td>
                <td>{repair.technician_name}</td>
                <td>{repair.technician_phone}</td>
                <td>{repair.technician_email}</td>
                <td>{repair.rating}</td>
                <td>{repair.opening_date}</td>
                <td>{repair.closing_date}</td>
                <td>{repair.problem_description}</td>
                <td>{repair.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UserRepairs;
