// src/components/agentComponents/Selection.jsx
import React, { useState } from "react";
import styles from "./Selection.module.css";

const Selection = ({ onSelectSection }) => {
  const [selectedButton, setSelectedButton] = useState("");

  const handleButtonClick = (section) => {
    setSelectedButton(section);
    onSelectSection(section);
  };

  return (
    <div className={styles.selection}>
      <button
        className={selectedButton === "console" ? styles.selected : ""}
        onClick={() => handleButtonClick("console")}
      >
        Console
      </button>
      <button
        className={selectedButton === "service" ? styles.selected : ""}
        onClick={() => handleButtonClick("service")}
      >
        Service
      </button>
      <button
        className={selectedButton === "repairs" ? styles.selected : ""}
        onClick={() => handleButtonClick("repairs")}
      >
        Repairs
      </button>
    </div>
  );
};

export default Selection;
