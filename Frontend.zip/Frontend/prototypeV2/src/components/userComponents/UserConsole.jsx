import React, { useState } from "react";
import axios from "axios";
import styles from "./UserConsole.module.css";

const UserConsole = ({
  equipmentDetails,
  nameToIdMapping,
  updateEquipmentName,
}) => {
  const [editing, setEditing] = useState({});
  const [editedNames, setEditedNames] = useState(
    equipmentDetails.reduce((acc, equipment) => {
      acc[equipment.equipment_id] = equipment.name;
      return acc;
    }, {})
  );

  const handleEditClick = (equipmentId) => {
    setEditing({ ...editing, [equipmentId]: true });
  };

  const handleNameChange = (equipmentId, newName) => {
    setEditedNames({ ...editedNames, [equipmentId]: newName });
  };

  const handleSaveClick = async (equipmentId) => {
    try {
      const response = await axios.post(
        "http://localhost:5000/api/user/update_equipment_name",
        {
          equipment_id: equipmentId,
          new_name: editedNames[equipmentId],
        }
      );

      if (response.data.success) {
        setEditing({ ...editing, [equipmentId]: false });
        updateEquipmentName(equipmentId, editedNames[equipmentId]);
      } else {
        console.error("Error updating equipment name:", response.data.message);
      }
    } catch (err) {
      console.error("Error updating equipment name:", err);
    }
  };

  return (
    <div className={styles.container}>
      <h2 className={styles.heading}>User Console</h2>
      <table className={styles.table}>
        <thead>
          <tr>
            <th>Equipment ID</th>
            <th>Type</th>
            <th>Name</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {equipmentDetails.map((equipment) => (
            <tr key={equipment.equipment_id}>
              <td>{equipment.equipment_id}</td>
              <td>{equipment.type}</td>
              <td>
                {editing[equipment.equipment_id] ? (
                  <input
                    type="text"
                    value={editedNames[equipment.equipment_id]}
                    onChange={(e) =>
                      handleNameChange(equipment.equipment_id, e.target.value)
                    }
                    className={styles.input}
                  />
                ) : (
                  editedNames[equipment.equipment_id]
                )}
              </td>
              <td>
                {editing[equipment.equipment_id] ? (
                  <button
                    onClick={() => handleSaveClick(equipment.equipment_id)}
                    className={styles.saveButton}
                  >
                    Save
                  </button>
                ) : (
                  <button
                    onClick={() => handleEditClick(equipment.equipment_id)}
                    className={styles.editButton}
                  >
                    Edit
                  </button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default UserConsole;
