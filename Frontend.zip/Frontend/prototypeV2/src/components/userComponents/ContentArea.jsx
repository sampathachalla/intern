import React, { useState, useEffect } from "react";
import axios from "axios";
import styles from "./ContentArea.module.css";
import UserConsole from "./UserConsole";
import UserService from "./UserService";
import UserRepairs from "./UserRepairs";

const ContentArea = ({ section, username }) => {
  const [userDetails, setUserDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [refresh, setRefresh] = useState(false); // State to trigger refresh

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.post(
          "http://localhost:5000/api/user/fetch_user_details",
          { username }
        );
        setUserDetails(response.data);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching user details:", err);
        setError("Error fetching user details");
        setLoading(false);
      }
    };

    fetchData();
  }, [username, refresh]); // Add refresh to dependency array

  const updateEquipmentName = (equipmentId, newName) => {
    if (userDetails) {
      const updatedEquipmentDetailsList =
        userDetails.equipment_details_list.map((equipment) =>
          equipment.equipment_id === equipmentId
            ? { ...equipment, name: newName }
            : equipment
        );

      // Create a new nameToIdMapping object
      const updatedNameToIdMapping = { ...userDetails.name_to_id_mapping };

      // Find the old name and delete it
      const oldName = Object.keys(updatedNameToIdMapping).find(
        (key) => updatedNameToIdMapping[key] === equipmentId
      );
      delete updatedNameToIdMapping[oldName];

      // Add the new name
      updatedNameToIdMapping[newName] = equipmentId;

      setUserDetails({
        ...userDetails,
        equipment_details_list: updatedEquipmentDetailsList,
        name_to_id_mapping: updatedNameToIdMapping,
      });
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  let content;
  switch (section) {
    case "console":
      content = userDetails ? (
        <UserConsole
          equipmentDetails={userDetails.equipment_details_list}
          nameToIdMapping={userDetails.name_to_id_mapping}
          updateEquipmentName={updateEquipmentName}
        />
      ) : (
        <div>No equipment details available</div>
      );
      break;
    case "service":
      content = userDetails ? (
        <UserService nameToIdMapping={userDetails.name_to_id_mapping} />
      ) : (
        <div>No service details available</div>
      );
      break;
    case "repairs":
      content = userDetails ? (
        <UserRepairs
          repairDetails={userDetails.service_repair_details_list}
          nameToIdMapping={userDetails.name_to_id_mapping}
        />
      ) : (
        <div>No repair details available</div>
      );
      break;
    default:
      content = <div>Welcome to the User Dashboard</div>;
  }

  return (
    <main className={styles.contentArea}>
      <div className={styles.refreshButtonContainer}>
        <button
          className={styles.refreshButton}
          onClick={() => setRefresh(!refresh)}
        >
          Refresh
        </button>
      </div>
      {content}
    </main>
  );
};

export default ContentArea;
